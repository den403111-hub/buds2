package com.budspopup

import android.graphics.Path
import android.graphics.RectF

/** Форми вікна: 0 закруглений, 1 пігулка, 2 гострі кути, 3 зрізані кути, 4 асиметричний. Усі опуклі. */
object ShapePath {
    fun make(rc: RectF, shape: Int, r0: Float): Path {
        val p = Path()
        val maxR = minOf(rc.width(), rc.height()) / 2f
        val r = r0.coerceIn(0f, maxR)
        when (shape) {
            1 -> p.addRoundRect(rc, maxR, maxR, Path.Direction.CW)
            2 -> p.addRect(rc, Path.Direction.CW)
            3 -> {
                val c = r
                p.moveTo(rc.left + c, rc.top)
                p.lineTo(rc.right - c, rc.top)
                p.lineTo(rc.right, rc.top + c)
                p.lineTo(rc.right, rc.bottom - c)
                p.lineTo(rc.right - c, rc.bottom)
                p.lineTo(rc.left + c, rc.bottom)
                p.lineTo(rc.left, rc.bottom - c)
                p.lineTo(rc.left, rc.top + c)
                p.close()
            }
            4 -> {
                val big = (r * 1.8f).coerceAtMost(maxR)
                val small = r * 0.25f
                // лівий верх, правий верх, правий низ, лівий низ
                val radii = floatArrayOf(big, big, small, small, big, big, small, small)
                p.addRoundRect(rc, radii, Path.Direction.CW)
            }
            else -> p.addRoundRect(rc, r, r, Path.Direction.CW)
        }
        return p
    }

    /** Приблизний радіус кутів для відступів вмісту. */
    fun effectiveRadius(shape: Int, r: Float, heightPx: Int): Float = when (shape) {
        1 -> heightPx / 2f
        2 -> 0f
        4 -> r * 1.8f
        else -> r
    }
}
