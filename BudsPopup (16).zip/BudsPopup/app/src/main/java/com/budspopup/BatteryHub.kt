package com.budspopup

import android.os.Handler
import android.os.Looper

/** Заряд. total = загальний; left/right/caseLevel = окремо (якщо вдалося отримати). */
class Battery {
    var total: Int? = null
    var left: Int? = null
    var right: Int? = null
    var caseLevel: Int? = null
}

/** Спільне сховище заряду для сервісу Bluetooth і читача сповіщень realme Link. */
object BatteryHub {
    val PACKAGES = setOf("com.realme.link", "com.heytap.headset", "com.oplus.melody")

    val battery = Battery()
    var onChange: (() -> Unit)? = null
    var rescan: (() -> Unit)? = null

    private val main = Handler(Looper.getMainLooper())

    fun reset() {
        battery.total = null; battery.left = null; battery.right = null; battery.caseLevel = null
    }

    fun changed() {
        main.post { onChange?.invoke() }
    }

    /** Шукає у тексті сповіщення "L 80%", "R 80%", "Кейс 20%" тощо. true, якщо щось оновилось. */
    fun parseText(text: String): Boolean {
        val pct = """(\d{1,3})\s*%"""
        fun find(label: String): Int? =
            Regex(label + """\D{0,8}""" + pct, RegexOption.IGNORE_CASE)
                .find(text)?.groupValues?.get(1)?.toIntOrNull()?.takeIf { it in 0..100 }

        val l = find("""(?:\bL\b|left|лів\p{L}*|左)""")
        val r = find("""(?:\bR\b|right|прав\p{L}*|右)""")
        val c = find("""(?:case|кейс|чохол|box|盒|仓)""")
        var changed = false
        if (l != null && l != battery.left) { battery.left = l; changed = true }
        if (r != null && r != battery.right) { battery.right = r; changed = true }
        if (c != null && c != battery.caseLevel) { battery.caseLevel = c; changed = true }
        if (l == null && r == null && c == null) {
            val all = Regex(pct).findAll(text).mapNotNull { it.groupValues[1].toIntOrNull() }
                .filter { it in 0..100 }.toList()
            if (all.size == 1 && all[0] != battery.total) { battery.total = all[0]; changed = true }
        }
        return changed
    }
}
