package com.budspopup

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import android.view.animation.DecelerateInterpolator

/**
 * Смужка заряду: плавно заповнюється і плавно змінює колір.
 * Зелена від 50%, жовта від 21% до 49%, червона на рівні порога попередження (за замовчуванням 20%) і нижче.
 */
class BatteryBar(private val ctx: Context) : View(ctx) {

    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x40FFFFFF }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val evaluator = ArgbEvaluator()

    private var frac = 0f
    private var color = GRAY
    private var target: Int? = null
    private var shown = false
    private var anim: ValueAnimator? = null

    private fun colorFor(level: Int?): Int {
        if (level == null) return GRAY
        val low = Prefs.int(ctx, "lowthr", 20)
        return when {
            level <= low -> RED
            level < 50 -> YELLOW
            else -> GREEN
        }
    }

    /** null = рівень невідомий (порожня смужка). */
    fun setLevel(level: Int?) {
        val t = level?.coerceIn(0, 100)
        if (shown && t == target) return
        val first = !shown
        target = t
        val toFrac = (t ?: 0) / 100f
        val toColor = colorFor(t)
        if (first) color = toColor           // перше заповнення: одразу правильний колір
        val fromFrac = frac
        val fromColor = color
        anim?.cancel()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 700
            startDelay = if (first) 250L else 0L
            interpolator = DecelerateInterpolator(1.6f)
            addUpdateListener {
                val k = it.animatedValue as Float
                frac = fromFrac + (toFrac - fromFrac) * k
                color = evaluator.evaluate(k, fromColor, toColor) as Int
                invalidate()
            }
            start()
        }
        shown = true
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = h / 2f
        rect.set(0f, 0f, w, h)
        c.drawRoundRect(rect, r, r, track)
        if (frac > 0.001f) {
            val fw = maxOf(h, w * frac)          // мінімум = висота, щоб кінець лишався круглим
            rect.set(0f, 0f, fw, h)
            fill.color = color
            c.drawRoundRect(rect, r, r, fill)
        }
    }

    companion object {
        private const val GRAY = 0xFF888888.toInt()
        private const val RED = 0xFFFF4D4D.toInt()
        private const val YELLOW = 0xFFFFC53D.toInt()
        private const val GREEN = 0xFF3DDC84.toInt()
    }
}
