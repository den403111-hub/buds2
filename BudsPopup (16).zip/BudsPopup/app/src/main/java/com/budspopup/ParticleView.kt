package com.budspopup

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/** Частинки на картці: 1 зірки, 2 конфеті, 3 сніжинки, 4 мікс. */
class ParticleView(ctx: Context, private val type: Int, private val count: Int) : View(ctx) {

    private class P(
        var x: Float, var y: Float, var vx: Float, var vy: Float,
        var size: Float, var rot: Float, var vr: Float,
        var phase: Float, var vp: Float, var color: Int, var kind: Int
    )

    private val rnd = java.util.Random()
    private val ps = ArrayList<P>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = ctx.resources.displayMetrics.density
    private var last = 0L

    // чотирипроменева зірка-іскорка в межах -1..1
    private val star = Path().apply {
        moveTo(0f, -1f)
        quadTo(0.14f, -0.14f, 1f, 0f)
        quadTo(0.14f, 0.14f, 0f, 1f)
        quadTo(-0.14f, 0.14f, -1f, 0f)
        quadTo(-0.14f, -0.14f, 0f, -1f)
        close()
    }

    private fun rf(a: Float, b: Float): Float = a + rnd.nextFloat() * (b - a)

    private fun make(initial: Boolean): P {
        val w = width.toFloat()
        val h = height.toFloat()
        val kind = if (type == 4) 1 + rnd.nextInt(3) else type
        val x = rf(0f, w)
        return when (kind) {
            1 -> P(
                x, if (initial) rf(0f, h) else h + 20f,
                rf(-6f, 6f) * d, -rf(8f, 22f) * d,
                rf(4f, 9f) * d, rf(0f, 90f), rf(-25f, 25f),
                rf(0f, 6.28f), rf(1.5f, 4f), STAR_COLORS[rnd.nextInt(STAR_COLORS.size)], 1
            )
            2 -> P(
                x, if (initial) rf(0f, h) else -20f,
                rf(-10f, 10f) * d, rf(70f, 150f) * d,
                rf(3f, 5.5f) * d, rf(0f, 360f), rf(-240f, 240f),
                rf(0f, 6.28f), rf(3f, 7f), CONFETTI_COLORS[rnd.nextInt(CONFETTI_COLORS.size)], 2
            )
            else -> P(
                x, if (initial) rf(0f, h) else -20f,
                0f, rf(25f, 60f) * d,
                rf(1.5f, 4.5f) * d, rf(0f, 360f), rf(-40f, 40f),
                rf(0f, 6.28f), rf(0.8f, 2f), Color.WHITE, 3
            )
        }
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        ps.clear()
        if (w <= 0 || h <= 0) return
        repeat(count) { ps.add(make(true)) }
        last = 0L
    }

    override fun onDraw(c: Canvas) {
        val now = System.nanoTime()
        val dt = if (last == 0L) 0.016f else ((now - last) / 1_000_000_000f).coerceIn(0f, 0.05f)
        last = now
        val w = width.toFloat()
        val h = height.toFloat()

        for (i in ps.indices) {
            val p = ps[i]
            p.phase += p.vp * dt
            p.rot += p.vr * dt
            when (p.kind) {
                1 -> { p.x += p.vx * dt; p.y += p.vy * dt }
                2 -> { p.x += (p.vx + sin(p.phase) * 30f * d) * dt; p.y += p.vy * dt }
                else -> { p.x += sin(p.phase) * 22f * d * dt; p.y += p.vy * dt }
            }
            if (p.x < 0f) p.x = w else if (p.x > w) p.x = 0f
            val gone = if (p.kind == 1) p.y < -p.size * 2f else p.y > h + p.size * 2f
            if (gone) { ps[i] = make(false); continue }

            when (p.kind) {
                1 -> {
                    val a = 0.35f + 0.65f * abs(sin(p.phase))
                    paint.style = Paint.Style.FILL
                    paint.color = p.color
                    paint.alpha = (255f * a).toInt()
                    c.save()
                    c.translate(p.x, p.y)
                    c.rotate(p.rot)
                    c.scale(p.size, p.size)
                    c.drawPath(star, paint)
                    c.restore()
                }
                2 -> {
                    paint.style = Paint.Style.FILL
                    paint.color = p.color
                    paint.alpha = 235
                    c.save()
                    c.translate(p.x, p.y)
                    c.rotate(p.rot)
                    c.scale(1f, abs(cos(p.phase)) * 0.9f + 0.1f)   // ефект перевертання
                    c.drawRect(-p.size, -p.size * 0.55f, p.size, p.size * 0.55f, paint)
                    c.restore()
                }
                else -> {
                    paint.color = Color.WHITE
                    paint.alpha = 220
                    if (p.size > 3.2f * d) {
                        // велика сніжинка з шести променів
                        paint.style = Paint.Style.STROKE
                        paint.strokeWidth = 1.2f * d
                        val s = p.size * 1.6f
                        for (k in 0 until 3) {
                            c.save()
                            c.translate(p.x, p.y)
                            c.rotate(p.rot + k * 60f)
                            c.drawLine(-s, 0f, s, 0f, paint)
                            c.restore()
                        }
                        paint.style = Paint.Style.FILL
                    } else {
                        paint.style = Paint.Style.FILL
                        c.drawCircle(p.x, p.y, p.size, paint)
                    }
                }
            }
        }
        postInvalidateOnAnimation()
    }

    companion object {
        private val STAR_COLORS = intArrayOf(
            0xFFFFFFFF.toInt(), 0xFFFFF3B0.toInt(), 0xFF9BF6FF.toInt(), 0xFFFFC6FF.toInt()
        )
        private val CONFETTI_COLORS = intArrayOf(
            0xFFFF595E.toInt(), 0xFFFFCA3A.toInt(), 0xFF8AC926.toInt(), 0xFF1982C4.toInt(),
            0xFF6A4C93.toInt(), 0xFFFF8FAB.toInt(), 0xFF00E5FF.toInt()
        )
    }
}
