package com.budspopup

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.SweepGradient
import android.view.View
import android.view.animation.LinearInterpolator

/**
 * Рамка / світіння навколо вікна.
 * effect: 1 проста, 2 неон, 3 неон пульсація, 4 веселка, 5 біжучий вогник.
 * glow = true: м'яке світіння ззовні (малюється ПІД карткою), false: сама лінія рамки (ПОВЕРХ картки).
 */
class BorderView(
    ctx: Context,
    private val shape: Int,
    private val radius: Float,
    private val effect: Int,
    private val color: Int,
    private val strokeW: Float,
    private val glow: Boolean,
    private val inset: Float,
    private val radiusMinus: Float
) : View(ctx) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND
    }
    private var path = Path()
    private var shader: SweepGradient? = null
    private val m = Matrix()
    private var rot = 0f
    private var pulse = 1f
    private var anim: ValueAnimator? = null

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val rc = RectF(inset, inset, w - inset, h - inset)
        path = ShapePath.make(rc, shape, (radius - radiusMinus).coerceAtLeast(0f))
        val cx = w / 2f
        val cy = h / 2f
        val clear = color and 0x00FFFFFF
        shader = when (effect) {
            4 -> SweepGradient(
                cx, cy,
                intArrayOf(
                    0xFFFF0000.toInt(), 0xFFFFFF00.toInt(), 0xFF00FF00.toInt(),
                    0xFF00FFFF.toInt(), 0xFF0000FF.toInt(), 0xFFFF00FF.toInt(), 0xFFFF0000.toInt()
                ),
                null
            )
            5 -> SweepGradient(cx, cy, intArrayOf(clear, clear, color), floatArrayOf(0f, 0.55f, 1f))
            else -> null
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        anim?.cancel()
        when (effect) {
            3 -> anim = ValueAnimator.ofFloat(0.3f, 1f).apply {
                duration = 900
                repeatMode = ValueAnimator.REVERSE
                repeatCount = ValueAnimator.INFINITE
                addUpdateListener { pulse = it.animatedValue as Float; invalidate() }
                start()
            }
            4, 5 -> anim = ValueAnimator.ofFloat(0f, 360f).apply {
                duration = if (effect == 5) 1800L else 3500L
                repeatCount = ValueAnimator.INFINITE
                interpolator = LinearInterpolator()
                addUpdateListener { rot = it.animatedValue as Float; invalidate() }
                start()
            }
        }
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        anim = null
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        if (path.isEmpty) return
        paint.shader = null
        paint.color = color
        shader?.let {
            m.setRotate(rot, width / 2f, height / 2f)
            it.setLocalMatrix(m)
            paint.shader = it
        }
        if (glow) {
            val gr = inset - strokeW / 2f
            val n = 5
            for (i in 0 until n) {
                val t = (i + 1) / n.toFloat()
                paint.strokeWidth = strokeW + 2f * gr * t
                paint.alpha = (255f * 0.34f * (1f - t * 0.85f) * pulse).toInt().coerceIn(0, 255)
                c.drawPath(path, paint)
            }
        } else {
            paint.strokeWidth = strokeW
            paint.alpha = 255
            c.drawPath(path, paint)
        }
    }
}
