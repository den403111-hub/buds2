package com.budspopup

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Малюнок інею, схожий на справжній: щільні пір'їсті кристали-папороті,
 * що переплітаються, з м'яким світінням і синювато-білим градієнтом.
 * Створюється один раз і кешується, тому при показі popup нічого не гальмує.
 */
object Frost {
    private var cached: Bitmap? = null

    fun get(ctx: Context, w: Int, h: Int): Bitmap {
        cached?.let { if (it.width == w && it.height == h) return it }
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val bg = Paint().apply {
            shader = LinearGradient(
                0f, 0f, w * 0.3f, h.toFloat(),
                intArrayOf(0xFFE3EFFC.toInt(), 0xFFA6CBF0.toInt(), 0xFF6F9FDB.toInt()),
                floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
            )
        }
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), bg)

        val d = ctx.resources.displayMetrics.density
        val rnd = java.util.Random(11)

        // м'яке світіння (широкі напівпрозорі лінії) і чіткі білі прожилки поверх
        val glowPath = Path()
        val crispPath = Path()
        val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xD0FFFFFF.toInt() }

        fun seg(x1: Float, y1: Float, x2: Float, y2: Float) {
            glowPath.moveTo(x1, y1); glowPath.lineTo(x2, y2)
            crispPath.moveTo(x1, y1); crispPath.lineTo(x2, y2)
        }

        // бічна гілочка: сама розгалужується ще на дві дрібніші
        fun twig(x: Float, y: Float, ang: Float, len: Float, depth: Int) {
            if (len < 1.5f * d || depth < 0) return
            val ex = x + cos(ang) * len
            val ey = y + sin(ang) * len
            seg(x, y, ex, ey)
            if (depth > 0) {
                for (side in intArrayOf(-1, 1)) {
                    val a2 = ang + side * (0.6f + rnd.nextFloat() * 0.5f)
                    twig(ex, ey, a2, len * (0.5f + rnd.nextFloat() * 0.15f), depth - 1)
                }
            }
        }

        // папороть: головне стебло з густими бічними гілками, що зменшуються до кінця
        fun frond(x0: Float, y0: Float, ang0: Float, len0: Float) {
            val steps = 9
            val step = len0 / steps
            var x = x0
            var y = y0
            var a = ang0
            for (s in 0 until steps) {
                val t = s.toFloat() / steps
                a += (rnd.nextFloat() - 0.5f) * 0.14f
                val nx = x + cos(a) * step
                val ny = y + sin(a) * step
                seg(x, y, nx, ny)
                val sideLen = len0 * 0.38f * (1f - t) * (0.75f + rnd.nextFloat() * 0.5f)
                for (side in intArrayOf(-1, 1)) {
                    val sa = a + side * (0.65f + rnd.nextFloat() * 0.4f)
                    twig(nx, ny, sa, sideLen, 2)
                }
                x = nx
                y = ny
            }
        }

        val count = (w * h) / 2000
        for (i in 0 until count) {
            val x = rnd.nextFloat() * w
            val y = rnd.nextFloat() * h
            val ang = rnd.nextFloat() * (2f * PI.toFloat())
            val len = (40f + rnd.nextFloat() * 90f) * d
            frond(x, y, ang, len)
        }

        val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            color = 0x3CFFFFFF
            strokeWidth = 3.4f * d
        }
        val crisp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            color = 0xB8FFFFFF.toInt()
            strokeWidth = 0.9f * d
        }
        c.drawPath(glowPath, glow)
        c.drawPath(crispPath, crisp)

        // дрібні іскорки кристалів
        for (i in 0 until (w * h) / 900) {
            dotPaint.alpha = 90 + rnd.nextInt(160)
            c.drawCircle(rnd.nextFloat() * w, rnd.nextFloat() * h, (0.5f + rnd.nextFloat() * 0.9f) * d, dotPaint)
        }

        cached = bmp
        return bmp
    }
}
