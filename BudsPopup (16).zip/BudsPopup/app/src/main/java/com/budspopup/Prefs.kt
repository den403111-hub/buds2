package com.budspopup

import android.content.Context
import java.io.File

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("buds", Context.MODE_PRIVATE)
    fun get(c: Context, k: String, d: String): String = sp(c).getString(k, d) ?: d
    fun put(c: Context, k: String, v: String) { sp(c).edit().putString(k, v).apply() }
    fun int(c: Context, k: String, d: Int): Int = sp(c).getInt(k, d)
    fun putInt(c: Context, k: String, v: Int) { sp(c).edit().putInt(k, v).apply() }
    fun bool(c: Context, k: String, d: Boolean = false): Boolean = sp(c).getBoolean(k, d)
    fun putBool(c: Context, k: String, v: Boolean) { sp(c).edit().putBoolean(k, v).apply() }
    fun file(c: Context, n: String): File? = File(c.filesDir, n).takeIf { it.exists() && it.length() > 0 }
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

object Colors {
    const val DEFAULT_BORDER = 0xFF00E5FF.toInt()

    fun border(c: Context): Int {
        val hex = Prefs.get(c, "bhex", "").trim()
        if (hex.isNotEmpty()) {
            try {
                return android.graphics.Color.parseColor(if (hex.startsWith("#")) hex else "#$hex")
            } catch (_: Exception) {
            }
        }
        return DEFAULT_BORDER
    }

    fun toHex(color: Int): String = String.format("#%06X", 0xFFFFFF and color)
}
