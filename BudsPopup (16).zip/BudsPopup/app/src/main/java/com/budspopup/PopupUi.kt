package com.budspopup

import android.animation.ValueAnimator
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.graphics.Outline
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.SurfaceTexture
import android.graphics.Typeface
import android.graphics.drawable.AnimatedImageDrawable
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.animation.ValueAnimator as CountAnimator
import kotlin.math.roundToInt
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.animation.AccelerateInterpolator
import android.view.animation.BounceInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

class PopupUi(private val ctx: Context) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private var root: FrameLayout? = null
    private var card: View? = null       // контейнер (картка + світіння), саме його і анімуємо
    private var budsBox: LinearLayout? = null
    private var caseBox: LinearLayout? = null
    private var player: MediaPlayer? = null
    private var backdrop: View? = null
    private var backdropLp: WindowManager.LayoutParams? = null
    private var backdropRadius = 0
    private var lastB: Battery? = null          // останні дані, для лічильника
    private var sfx: MediaPlayer? = null        // свій звук при підключенні
    private var countK = 1f                     // 0..1: скільки відсотків уже «набігло»
    private var countAnim: CountAnimator? = null
    private var particleView: View? = null
    private var garlandWin: View? = null

    private val pos get() = Prefs.int(ctx, "pos", 0)      // 0 знизу, 1 зверху
    private val anim get() = Prefs.int(ctx, "anim", 0)

    private fun borderColor(): Int = Colors.border(ctx)

    fun show(name: String, b: Battery) {
        if (!Settings.canDrawOverlays(ctx)) return
        dismissNow()

        val dm = ctx.resources.displayMetrics
        val sz = Prefs.int(ctx, "img", 100)
        val pad = ctx.dp(12)                       // місце під світіння
        val cardW = ((dm.widthPixels - ctx.dp(24)) * Prefs.int(ctx, "w", 100) / 100f).toInt()
        val cardH = ctx.dp(maxOf(Prefs.int(ctx, "h", 270), sz + 150))
        val shape = Prefs.int(ctx, "shape", 0)
        val radius = ctx.dp(Prefs.int(ctx, "radius", 28)).toFloat()
        val fx = Prefs.int(ctx, "bfx", 0)
        val bw = ctx.dp(Prefs.int(ctx, "bw", 3)).toFloat()
        val bcol = borderColor()

        lastB = b
        countK = if (Prefs.bool(ctx, "count", true)) 0f else 1f
        val c = buildCard(name, b, sz, cardW, cardH, shape, radius)
        if (fx >= 1) {
            c.addView(
                BorderView(ctx, shape, radius, fx, bcol, bw, false, bw / 2f, bw / 2f),
                FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT)
            )
        }

        val outer = FrameLayout(ctx)
        outer.clipChildren = false
        outer.clipToPadding = false
        if (fx >= 2) {
            outer.addView(
                BorderView(ctx, shape, radius, fx, bcol, bw, true, pad.toFloat(), 0f),
                FrameLayout.LayoutParams(cardW + 2 * pad, cardH + 2 * pad)
            )
        }
        outer.addView(c, FrameLayout.LayoutParams(cardW, cardH).apply { setMargins(pad, pad, pad, pad) })

        val r = FrameLayout(ctx)
        val margin = ctx.dp(Prefs.int(ctx, "mb", 16))
        val top = pos == 1
        r.addView(
            outer,
            FrameLayout.LayoutParams(cardW + 2 * pad, cardH + 2 * pad).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                if (top) topMargin = margin else bottomMargin = margin
            }
        )

        val lp = WindowManager.LayoutParams(
            MATCH_PARENT, WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = if (top) Gravity.TOP else Gravity.BOTTOM
        addBackdrop()                 // ефект скла (якщо увімкнено), додається ПІД popup
        addParticleOverlay(above = false)   // режим 2: частинки на задньому екрані, ПІД popup
        addGarlandWindow()            // гірлянда по краю екрана, під popup
        wm.addView(r, lp)
        addParticleOverlay(above = true)    // режим 1: частинки по всьому екрану, НАД popup
        root = r
        card = outer
        animateIn(outer)
        animateBackdrop(true)
        startCount()

        val secs = Prefs.get(ctx, "secs", "7").toIntOrNull() ?: 7
        handler.postDelayed({ dismiss() }, secs * 1000L)
    }

    /** Цифри набігають від 0 до реального значення. */
    private fun startCount() {
        countAnim?.cancel()
        if (countK >= 1f) return
        countAnim = CountAnimator.ofFloat(0f, 1f).apply {
            duration = 900
            startDelay = 200
            interpolator = android.view.animation.DecelerateInterpolator(1.5f)
            addUpdateListener {
                countK = it.animatedValue as Float
                renderNumbers()
            }
            start()
        }
    }

    private fun renderNumbers() {
        val b = lastB ?: return
        budsBox?.let { fillBuds(it, b) }
        caseBox?.let { fillCase(it, b) }
    }

    fun updateBattery(b: Battery) {
        lastB = b
        budsBox?.let { fillBuds(it, b) }
        caseBox?.let { fillCase(it, b) }
    }

    /** Іній: свій малюнок (якщо вибрано) або згенерований. */
    private fun frostDrawable(): android.graphics.drawable.Drawable {
        val dm = ctx.resources.displayMetrics
        val custom = Prefs.file(ctx, "frost")
        val bmp = custom?.let {
            val o = android.graphics.BitmapFactory.Options().apply { inSampleSize = 4 }
            android.graphics.BitmapFactory.decodeFile(it.absolutePath, o)
        } ?: Frost.get(ctx, dm.widthPixels / 2, dm.heightPixels / 2)
        return android.graphics.drawable.BitmapDrawable(ctx.resources, bmp).apply { alpha = 225 }
    }

    /** Гірлянда по краю всього екрана (режими 2 і 3). Дотики проходять крізь неї. */
    private fun addGarlandWindow() {
        val g = Prefs.int(ctx, "garl", 0)
        if (g != 2 && g != 3) return
        val v = GarlandView(
            ctx, 2, 0f, ctx.dp(5).toFloat(),
            Prefs.int(ctx, "garln", 28) * 2, Prefs.int(ctx, "garlst", 0)
        )
        val lp = WindowManager.LayoutParams(
            MATCH_PARENT, MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        v.alpha = 0f
        try {
            wm.addView(v, lp)
            garlandWin = v
            v.animate().alpha(1f).setDuration(400).start()
        } catch (_: Exception) {
        }
    }

    // ---------- ефект скла: розмиття екрана за popup ----------

    /** Окреме повноекранне вікно, яке не ловить дотики. На Android 12+ розмиває все, що за ним. */
    private fun addBackdrop() {
        if (!Prefs.bool(ctx, "glass", false)) return
        val v = View(ctx)
        val lp = WindowManager.LayoutParams(
            MATCH_PARENT, MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        var blurred = false
        backdropRadius = 0
        if (Build.VERSION.SDK_INT >= 31 && wm.isCrossWindowBlurEnabled) {
            lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
            lp.blurBehindRadius = 0
            backdropRadius = ctx.dp(Prefs.int(ctx, "glassr", 25))
            blurred = true
        }
        // трохи затемнення, щоб popup краще читався (сильніше, якщо розмиття недоступне)
        if (Prefs.int(ctx, "glassst", 0) == 1) {
            // морозне скло: блакитний відтінок + повторюваний іній поверх розмиття
            val bd = BitmapDrawable(ctx.resources, FrostTexture.get(ctx)).apply {
                setTileModeXY(Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
                alpha = if (blurred) 210 else 235
            }
            val tint = ColorDrawable(if (blurred) 0x553A7BD5 else 0x883A7BD5.toInt())
            v.background = LayerDrawable(arrayOf(tint, bd))
        } else {
            if (Prefs.int(ctx, "glassst", 1) == 1) {
            // заморожене скло: блакитний іній поверх розмитого екрана
            v.background = frostDrawable()
        } else {
            v.setBackgroundColor(if (blurred) 0x26000000 else 0x59000000)
        }
        }
        v.alpha = 0f
        try {
            wm.addView(v, lp)
            backdrop = v
            backdropLp = lp
        } catch (_: Exception) {
        }
    }

    private fun animateBackdrop(toShow: Boolean) {
        val v = backdrop ?: return
        val lp = backdropLp ?: return
        val target = backdropRadius
        ValueAnimator.ofFloat(if (toShow) 0f else 1f, if (toShow) 1f else 0f).apply {
            duration = if (toShow) 280L else 240L
            addUpdateListener {
                val f = it.animatedValue as Float
                v.alpha = f
                if (Build.VERSION.SDK_INT >= 31 && target > 0) {
                    lp.blurBehindRadius = (target * f).toInt()
                    try { wm.updateViewLayout(v, lp) } catch (_: Exception) {}
                }
            }
            start()
        }
    }

    /**
     * Повноекранне вікно з частинками (не ловить дотики).
     * above = true: додається ПІСЛЯ popup (режим 1), тому літає і над ним.
     * above = false: додається ДО popup (режим 2), тому popup закриває частинки.
     */
    private fun addParticleOverlay(above: Boolean) {
        val pt = Prefs.int(ctx, "particles", 0)
        val mode = Prefs.int(ctx, "pmode", 1)
        if (pt <= 0) return
        if (above && mode != 1) return
        if (!above && mode != 2) return
        val v = ParticleView(ctx, pt, Prefs.int(ctx, "ptdens", 30) * 2)
        val lp = WindowManager.LayoutParams(
            MATCH_PARENT, MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        )
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        v.alpha = 0f
        try {
            wm.addView(v, lp)
            particleView = v
            v.animate().alpha(1f).setDuration(350).start()
        } catch (_: Exception) {
        }
    }

    // ---------- анімації ----------
    // 0 пружина з краю, 1 плавний виїзд, 2 збільшення, 3 відскок, 4 збоку, 5 просто поява

    private fun offY(c: View): Float = (c.height + ctx.dp(80)) * (if (pos == 1) -1f else 1f)
    private fun offX(): Float = ctx.resources.displayMetrics.widthPixels.toFloat()

    private fun animateIn(c: View) {
        val t = anim
        c.alpha = 0f
        c.post {
            c.pivotX = c.width / 2f
            c.pivotY = c.height / 2f
            val a = c.animate()
            when (t) {
                0 -> { c.translationY = offY(c); c.alpha = 1f
                    a.translationY(0f).setDuration(450).setInterpolator(OvershootInterpolator(0.9f)) }
                1 -> { c.translationY = offY(c); c.alpha = 1f
                    a.translationY(0f).setDuration(380).setInterpolator(DecelerateInterpolator(2f)) }
                2 -> { c.scaleX = 0.6f; c.scaleY = 0.6f
                    a.alpha(1f).scaleX(1f).scaleY(1f).setDuration(380).setInterpolator(OvershootInterpolator(1.4f)) }
                3 -> { c.translationY = offY(c); c.alpha = 1f
                    a.translationY(0f).setDuration(750).setInterpolator(BounceInterpolator()) }
                4 -> { c.translationX = offX(); c.alpha = 1f
                    a.translationX(0f).setDuration(420).setInterpolator(DecelerateInterpolator(1.8f)) }
                else -> a.alpha(1f).setDuration(350)
            }
            a.start()
        }
    }

    fun dismiss() {
        val c = card ?: return
        animateBackdrop(false)
        particleView?.animate()?.alpha(0f)?.setDuration(240)?.start()
        garlandWin?.animate()?.alpha(0f)?.setDuration(240)?.start()
        val a = c.animate().setDuration(260).setInterpolator(AccelerateInterpolator())
        when (anim) {
            2 -> a.alpha(0f).scaleX(0.7f).scaleY(0.7f)
            5 -> a.alpha(0f)
            4 -> a.translationX(offX())
            else -> a.translationY(offY(c))
        }
        a.withEndAction { if (card === c) dismissNow() }.start()
    }

    /** Програє свій звук (файл, який вибрав користувач). Викликається при підключенні. */
    fun playConnectSound() {
        if (Prefs.int(ctx, "sound", 0) != 1) return
        val f = Prefs.file(ctx, "sound") ?: return
        try {
            sfx?.release()
            val vol = Prefs.int(ctx, "svol", 80) / 100f
            val mp = MediaPlayer()
            sfx = mp
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            mp.setDataSource(f.absolutePath)
            mp.setVolume(vol, vol)
            mp.setOnPreparedListener { it.start() }
            mp.setOnCompletionListener { it.release(); if (sfx === it) sfx = null }
            mp.prepareAsync()
        } catch (_: Exception) {
        }
    }

    fun dismissNow() {
        try { sfx?.release() } catch (_: Exception) {}
        sfx = null
        countAnim?.cancel()
        countAnim = null
        handler.removeCallbacksAndMessages(null)
        player?.let {
            try { it.stop() } catch (_: Exception) {}
            try { it.release() } catch (_: Exception) {}
        }
        player = null
        root?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        backdrop?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        backdrop = null; backdropLp = null
        particleView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        particleView = null
        garlandWin?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        garlandWin = null
        root = null; card = null; budsBox = null; caseBox = null
    }

    // ---------- побудова картки ----------

    private fun buildCard(name: String, b: Battery, sz: Int, cardW: Int, cardH: Int, shape: Int, radius: Float): FrameLayout {
        val c = FrameLayout(ctx)
        c.setBackgroundColor(0xFF1B1B1F.toInt())
        c.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) {
                if (v.width == 0 || v.height == 0) { o.setEmpty(); return }
                o.setConvexPath(ShapePath.make(RectF(0f, 0f, v.width.toFloat(), v.height.toFloat()), shape, radius))
            }
        }
        c.clipToOutline = true
        c.elevation = ctx.dp(10).toFloat()
        c.setOnClickListener { dismiss() }

        addBackground(c, cardW, cardH)

        c.addView(
            View(ctx).apply {
                background = GradientDrawable(
                    GradientDrawable.Orientation.TOP_BOTTOM,
                    intArrayOf(0x00000000, 0xB0000000.toInt())
                )
            },
            FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT)
        )

        // частинки (зірки / конфеті / сніжинки), під текстом і кнопками
        val pt = Prefs.int(ctx, "particles", 0)
        if (pt > 0 && Prefs.int(ctx, "pmode", 1) == 0) {
            c.addView(
                ParticleView(ctx, pt, Prefs.int(ctx, "ptdens", 30)),
                FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT)
            )
        }

        // новорічна гірлянда по рамці popup
        val gp = Prefs.int(ctx, "garl", 0)
        if (gp == 1 || gp == 3) {
            c.addView(
                GarlandView(ctx, shape, radius, ctx.dp(6).toFloat(), Prefs.int(ctx, "garln", 28), Prefs.int(ctx, "garlst", 0)),
                FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT)
            )
        }

        // відступи вмісту залежать від форми, щоб текст не різало кутами
        val effR = ShapePath.effectiveRadius(shape, radius, cardH)
        val padH = ctx.dp(18) + (effR * 0.3f).toInt()
        val padT = ctx.dp(14) + (effR * 0.12f).toInt()
        val padB = ctx.dp(16) + (effR * 0.12f).toInt()
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(padH, padT, padH, padB)
        }

        val bb = batteryBox(); val cb = batteryBox()
        budsBox = bb; caseBox = cb
        fillBuds(bb, b); fillCase(cb, b)

        val top = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        top.addView(column("buds", R.drawable.ic_buds, bb, sz), LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        top.addView(column("case", R.drawable.ic_case, cb, sz), LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        col.addView(top, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))

        col.addView(
            TextView(ctx).apply {
                text = name
                setTextColor(Color.WHITE)
                textSize = 20f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER_HORIZONTAL
                setShadowLayer(6f, 0f, 1f, Color.BLACK)
            },
            LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply {
                topMargin = ctx.dp(4); bottomMargin = ctx.dp(8)
            }
        )

        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(
            pill("Setting", Color.WHITE, Color.BLACK, shape, radius) { dismiss(); openBtSettings() },
            LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply { marginEnd = ctx.dp(6) }
        )
        row.addView(
            pill("Open", 0xFF444444.toInt(), Color.WHITE, shape, radius) { dismiss(); openCompanionApp() },
            LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply { marginStart = ctx.dp(6) }
        )
        col.addView(row, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        c.addView(col, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        return c
    }

    private fun batteryBox() = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
    }

    private fun column(file: String, placeholder: Int, box: LinearLayout, sz: Int) = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        addView(img(file, placeholder), LinearLayout.LayoutParams(ctx.dp(sz), ctx.dp(sz)))
        addView(box, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = ctx.dp(4) })
    }

    /** Фон: GIF / фото (обрізається по центру) або відео (без звуку, по колу, теж на всю картку). */
    private fun addBackground(c: FrameLayout, cardW: Int, cardH: Int) {
        val f = Prefs.file(ctx, "bg") ?: return
        try {
            if (Prefs.bool(ctx, "bg_video")) {
                // кадр-заглушка: показується одразу, поки відео готується (щоб не було підлагування)
                poster(f)?.let { bmp ->
                    val pv = ImageView(ctx)
                    pv.scaleType = ImageView.ScaleType.CENTER_CROP
                    pv.setImageBitmap(bmp)
                    c.addView(pv, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
                }
                val tv = TextureView(ctx)
                val mp = MediaPlayer()
                player = mp
                var prepared = false
                var surface: Surface? = null
                fun tryStart() {
                    val s = surface
                    if (prepared && s != null) {
                        try { mp.setSurface(s); mp.start() } catch (_: Exception) {}
                    }
                }
                // готуємо відео ОДРАЗУ, не чекаючи вікна
                mp.setDataSource(f.absolutePath)
                mp.isLooping = true
                val sv = Prefs.int(ctx, "svol", 80) / 100f
                val useVideoSound = Prefs.int(ctx, "sound", 0) == 2
                mp.setVolume(if (useVideoSound) sv else 0f, if (useVideoSound) sv else 0f)
                mp.setOnVideoSizeChangedListener { _, vw, vh -> coverFit(tv, vw, vh, cardW, cardH) }
                mp.setOnPreparedListener { prepared = true; tryStart() }
                mp.prepareAsync()
                tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                    override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
                        surface = Surface(st)
                        tryStart()
                    }
                    override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {}
                    override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean = true
                    override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
                }
                c.addView(tv, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
            } else {
                val iv = ImageView(ctx)
                iv.scaleType = ImageView.ScaleType.CENTER_CROP
                val d = ImageDecoder.decodeDrawable(ImageDecoder.createSource(f))
                iv.setImageDrawable(d)
                if (d is AnimatedImageDrawable) {
                    d.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE
                    d.start()
                }
                c.addView(iv, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
            }
        } catch (_: Exception) {
        }
    }

    /** Перший кадр відео (кешується у файл), щоб одразу показати картинку. */
    private fun poster(video: java.io.File): android.graphics.Bitmap? {
        val pf = java.io.File(ctx.filesDir, "bg_poster.jpg")
        try {
            if (pf.exists() && pf.length() > 0) return android.graphics.BitmapFactory.decodeFile(pf.absolutePath)
            val r = android.media.MediaMetadataRetriever()
            r.setDataSource(video.absolutePath)
            val frame = r.getFrameAtTime(0, android.media.MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
            r.release()
            if (frame == null) return null
            val maxW = 720
            val bmp = if (frame.width > maxW) {
                android.graphics.Bitmap.createScaledBitmap(frame, maxW, frame.height * maxW / frame.width, true)
            } else frame
            pf.outputStream().use { bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 85, it) }
            return bmp
        } catch (_: Throwable) {
            return null
        }
    }

    /** Розтягує відео так, щоб воно закривало всю картку (як CENTER_CROP). */
    private fun coverFit(tv: TextureView, vw: Int, vh: Int, w: Int, h: Int) {
        if (vw <= 0 || vh <= 0 || w <= 0 || h <= 0) return
        val scale = maxOf(w.toFloat() / vw, h.toFloat() / vh)
        val sx = vw * scale / w
        val sy = vh * scale / h
        val m = Matrix()
        m.setScale(sx, sy, w / 2f, h / 2f)
        tv.setTransform(m)
    }

    private fun img(fileName: String, placeholder: Int): ImageView = ImageView(ctx).apply {
        scaleType = ImageView.ScaleType.FIT_CENTER
        val f = Prefs.file(ctx, fileName)
        if (f != null) {
            setImageURI(Uri.fromFile(f))
        } else {
            setImageResource(placeholder)
            setColorFilter(Color.WHITE)
        }
    }

    private fun pct(v: Int?): String = v?.let { "${(it * countK).roundToInt()}%" } ?: "—"

    // Тексти і смужки створюються один раз, потім лише оновлюються (щоб смужки плавно рухались).
    private var budsText: TextView? = null
    private var barL: BatteryBar? = null
    private var barR: BatteryBar? = null
    private var caseText: TextView? = null
    private var barC: BatteryBar? = null

    private fun fillBuds(box: LinearLayout, b: Battery) {
        if (box.childCount == 0) {
            val t = batText("")
            budsText = t
            box.addView(t, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT))
            if (Prefs.bool(ctx, "bars", true)) {
                val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
                val l = BatteryBar(ctx)
                val r = BatteryBar(ctx)
                barL = l; barR = r
                row.addView(l, LinearLayout.LayoutParams(0, ctx.dp(6), 1f).apply { marginEnd = ctx.dp(3) })
                row.addView(r, LinearLayout.LayoutParams(0, ctx.dp(6), 1f).apply { marginStart = ctx.dp(3) })
                box.addView(row, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = ctx.dp(4) })
            }
        }
        val hasLR = b.left != null || b.right != null
        budsText?.text = when {
            hasLR -> "L ${pct(b.left)}  ·  R ${pct(b.right)}"
            b.total != null -> "🎧 ${pct(b.total)}"
            else -> "…"
        }
        barL?.setLevel(if (hasLR) b.left else b.total)
        barR?.setLevel(if (hasLR) b.right else null)
        barR?.visibility = if (hasLR) View.VISIBLE else View.GONE   // лише загальний заряд: одна довга смужка
    }

    private fun fillCase(box: LinearLayout, b: Battery) {
        if (box.childCount == 0) {
            val t = batText("")
            caseText = t
            box.addView(t, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT))
            if (Prefs.bool(ctx, "bars", true)) {
                val bar = BatteryBar(ctx)
                barC = bar
                box.addView(bar, LinearLayout.LayoutParams(MATCH_PARENT, ctx.dp(6)).apply { topMargin = ctx.dp(4) })
            }
        }
        caseText?.text = "Кейс ${pct(b.caseLevel)}"
        barC?.setLevel(b.caseLevel)
    }

    private fun batText(s: String) = TextView(ctx).apply {
        text = s
        isSingleLine = true
        setTextColor(Color.WHITE)
        textSize = 13.5f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setShadowLayer(6f, 0f, 1f, Color.BLACK)
    }

    /** Кнопки: пігулка при формах "Пігулка"/"Закруглений", прямокутні при гострих кутах. */
    private fun pill(label: String, bg: Int, fg: Int, shape: Int, radius: Float, onClick: () -> Unit) = TextView(ctx).apply {
        text = label
        gravity = Gravity.CENTER
        setTextColor(fg)
        textSize = 15f
        typeface = Typeface.DEFAULT_BOLD
        background = GradientDrawable().apply {
            cornerRadius = when (shape) {
                2, 3 -> ctx.dp(6).toFloat()
                else -> ctx.dp(24).toFloat()
            }
            setColor(bg)
        }
        setPadding(0, ctx.dp(12), 0, ctx.dp(12))
        setOnClickListener { onClick() }
    }

    private fun openBtSettings() {
        try {
            ctx.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
        }
    }

    private fun openCompanionApp() {
        for (p in listOf("com.realme.link", "com.heytap.headset", "com.oplus.melody")) {
            val i = ctx.packageManager.getLaunchIntentForPackage(p)
            if (i != null) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try { ctx.startActivity(i) } catch (_: Exception) {}
                return
            }
        }
        openBtSettings()
    }
}
