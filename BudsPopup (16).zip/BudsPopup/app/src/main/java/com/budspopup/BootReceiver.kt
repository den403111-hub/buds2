package com.budspopup

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Intent.ACTION_BOOT_COMPLETED || !Prefs.bool(c, "enabled")) return
        try {
            c.startForegroundService(Intent(c, PopupService::class.java))
        } catch (_: Exception) {
        }
    }
}
