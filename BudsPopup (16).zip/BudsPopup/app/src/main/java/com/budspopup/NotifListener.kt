package com.budspopup

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Експериментально: читає сповіщення realme Link / HeyMelody і намагається знайти там заряд.
 * Працює, лише якщо ці додатки показують заряд у сповіщенні та ти дав "Доступ до сповіщень".
 */
class NotifListener : NotificationListenerService() {

    override fun onListenerConnected() {
        BatteryHub.rescan = { scan() }
        scan()
    }

    override fun onListenerDisconnected() {
        BatteryHub.rescan = null
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        handle(sbn)
    }

    private fun scan() {
        try {
            activeNotifications?.forEach { handle(it) }
        } catch (_: Exception) {
        }
    }

    private fun handle(sbn: StatusBarNotification) {
        if (sbn.packageName !in BatteryHub.PACKAGES) return
        val e = sbn.notification.extras
        val text = listOfNotNull(
            e.getCharSequence(Notification.EXTRA_TITLE),
            e.getCharSequence(Notification.EXTRA_TEXT),
            e.getCharSequence(Notification.EXTRA_BIG_TEXT),
            e.getCharSequence(Notification.EXTRA_SUB_TEXT)
        ).joinToString(" | ") { it.toString() }
        Diag.add(this, "NOTIF ${sbn.packageName}: $text")
        if (BatteryHub.parseText(text)) BatteryHub.changed()
    }
}
