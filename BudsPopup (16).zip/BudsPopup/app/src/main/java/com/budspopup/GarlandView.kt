package com.budspopup

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import android.graphics.RectF
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.cos

/**
 * Новорічна гірлянда: лампочки по контуру.
 * style 0 — бігуча хвиля (світло «біжить» по колу), style 1 — мерехтіння (групи по черзі).
 * shape/radius/inset — та сама форма, що й у popup (для екрана: shape 2, radius 0).
 */
class GarlandView(
    ctx: Context,
    private val shape: Int,
    private val radius: Float,
    private val inset: Float,
    private val count: Int,
    private val style: Int
) : View(ctx) {

    private val d = ctx.resources.displayMetrics.density
    private val wire = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f * d
        color = 0xFF0F3320.toInt()
    }
    private val bulb = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private var path = Path()
    private var xs = FloatArray(0)
    private var ys = FloatArray(0)
    private var phase = 0f
    private var anim: ValueAnimator? = null

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        if (w <= 0 || h <= 0 || count <= 0) return
        val rc = RectF(inset, inset, w - inset, h - inset)
        path = ShapePath.make(rc, shape, (radius - inset).coerceAtLeast(0f))
        val pm = PathMeasure(path, true)
        val len = pm.length
        xs = FloatArray(count)
        ys = FloatArray(count)
        val pos = FloatArray(2)
        for (i in 0 until count) {
            pm.getPosTan(len * i / count, pos, null)
            xs[i] = pos[0]
            ys[i] = pos[1]
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        anim?.cancel()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = if (style == 1) 1100L else 2600L
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener {
                phase = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        anim = null
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        if (xs.isEmpty()) return
        c.drawPath(path, wire)
        val r = 3.6f * d
        for (i in 0 until count) {
            val b: Float = if (style == 1) {
                // мерехтіння: по черзі світяться групи з 4 кольорів
                if (i % 4 == (phase * 4).toInt() % 4) 1f else 0.12f
            } else {
                // бігуча хвиля: світло ніби біжить по колу
                0.2f + 0.8f * (0.5f + 0.5f * cos(2f * PI.toFloat() * (phase - i / 4f)))
            }
            val color = COLORS[i % COLORS.size]
            glow.color = color
            glow.alpha = (70f * b).toInt()
            c.drawCircle(xs[i], ys[i], r * 2.4f, glow)
            bulb.color = color
            bulb.alpha = (255f * b).toInt()
            c.drawCircle(xs[i], ys[i], r, bulb)
        }
    }

    companion object {
        private val COLORS = intArrayOf(
            0xFFFF3B3B.toInt(),   // червоний
            0xFF3BFF6A.toInt(),   // зелений
            0xFFFFD33B.toInt(),   // золотий
            0xFF3BA7FF.toInt()    // синій
        )
    }
}
