package com.budspopup

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Простий журнал для діагностики (що саме приходить від навушників / realme Link). */
object Diag {
    private fun f(c: Context) = File(c.filesDir, "diag.txt")

    @Synchronized
    fun add(c: Context, line: String) {
        try {
            val t = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
            val file = f(c)
            file.appendText("$t $line\n")
            if (file.length() > 30000) file.writeText(file.readText().takeLast(15000))
        } catch (_: Exception) {
        }
    }

    fun read(c: Context): String = try {
        f(c).takeIf { it.exists() }?.readText()?.ifBlank { null } ?: "(порожньо)"
    } catch (_: Exception) {
        "(помилка читання)"
    }

    fun clear(c: Context) {
        try { f(c).delete() } catch (_: Exception) {}
    }
}
