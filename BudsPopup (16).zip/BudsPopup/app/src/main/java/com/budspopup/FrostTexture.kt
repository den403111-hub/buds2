package com.budspopup

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import java.io.File
import kotlin.math.cos
import kotlin.math.sin

/**
 * Візерунок інію (ледяні папороті), створюється один раз і зберігається у файл.
 * Не потребує жодних картинок з інтернету.
 */
object FrostTexture {
    private const val SIZE = 512

    fun get(ctx: Context): Bitmap {
        val f = File(ctx.filesDir, "frost.png")
        if (f.exists() && f.length() > 0) {
            BitmapFactory.decodeFile(f.absolutePath)?.let { return it }
        }
        val bmp = generate()
        try {
            f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        } catch (_: Exception) {
        }
        return bmp
    }

    private fun generate(): Bitmap {
        val bmp = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val rnd = java.util.Random(42)          // фіксований seed: завжди однаковий візерунок
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }

        // ледяні папороті: гілки, що роздвоюються
        repeat(46) {
            val x = rnd.nextFloat() * SIZE
            val y = rnd.nextFloat() * SIZE
            val a = rnd.nextFloat() * 6.2832f
            grow(c, p, rnd, x, y, a, 46f + rnd.nextFloat() * 30f, 7)
        }

        // дрібні кристалики
        val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        repeat(420) {
            dot.color = Color.argb(120 + rnd.nextInt(120), 255, 255, 255)
            c.drawCircle(rnd.nextFloat() * SIZE, rnd.nextFloat() * SIZE, 0.7f + rnd.nextFloat() * 1.6f, dot)
        }
        return bmp
    }

    private fun grow(c: Canvas, p: Paint, rnd: java.util.Random, x: Float, y: Float, ang: Float, len: Float, depth: Int) {
        if (depth == 0 || len < 3f) return
        val x2 = x + cos(ang) * len
        val y2 = y + sin(ang) * len
        p.strokeWidth = 0.6f + depth * 0.32f
        p.color = Color.argb(150 + depth * 12, 255, 255, 255)
        c.drawLine(x, y, x2, y2, p)
        val spread = 0.35f + rnd.nextFloat() * 0.35f
        grow(c, p, rnd, x2, y2, ang + spread, len * (0.68f + rnd.nextFloat() * 0.08f), depth - 1)
        grow(c, p, rnd, x2, y2, ang - spread, len * (0.68f + rnd.nextFloat() * 0.08f), depth - 1)
    }
}
