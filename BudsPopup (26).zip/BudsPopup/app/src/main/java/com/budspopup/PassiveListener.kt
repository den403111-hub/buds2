package com.budspopup

import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Context

/**
 * Пасивне слухання каналу навушників: тримає RFCOMM-з'єднання відкритим і записує
 * усі пакети, які приходять, без запитів (крім одного рукостискання).
 * Потрібен, щоб побачити, що навушники самі повідомляють під час зміни режиму в realme Link.
 */
object PassiveListener {
    @Volatile var running = false
    private var thread: Thread? = null
    @Volatile private var sock: BluetoothSocket? = null

    fun start(ctx: Context, d: BluetoothDevice) {
        if (running) return
        Diag.clear(ctx)
        Diag.add(ctx, "LISTEN старт (журнал очищено)")
        running = true
        thread = Thread { loop(ctx, d) }.apply { name = "buds-listen"; start() }
    }

    fun stop(ctx: Context) {
        if (!running) return
        running = false
        try { sock?.close() } catch (_: Exception) {}
        thread?.interrupt()
        thread = null
        Diag.add(ctx, "LISTEN зупинено")
    }

    private fun loop(ctx: Context, d: BluetoothDevice) {
        var warned = false
        while (running) {
            val s = OppoRfcomm.connectForListen(ctx, d)
            if (s == null) {
                if (!warned) {
                    Diag.add(ctx, "LISTEN: навушники не відповідають, повторюю кожні 5 с")
                    warned = true
                }
                sleepQuiet(5000)
                continue
            }
            warned = false
            sock = s
            Diag.add(ctx, "LISTEN підключено")
            try {
                s.outputStream.write(OppoRfcomm.handshakeBytes())
                s.outputStream.flush()
                val inp = s.inputStream
                val buf = ByteArray(512)
                while (running) {
                    val n = inp.read(buf)
                    if (n < 0) break
                    if (n > 0) Diag.add(ctx, "LISTEN rx ${OppoRfcomm.hexOf(buf, n)}")
                }
            } catch (e: Exception) {
                if (running) Diag.add(ctx, "LISTEN помилка: ${e.message}")
            } finally {
                try { s.close() } catch (_: Exception) {}
                sock = null
            }
            if (running) {
                Diag.add(ctx, "LISTEN: з'єднання розірвано, повтор через 3 с")
                sleepQuiet(3000)
            }
        }
    }

    private fun sleepQuiet(ms: Long) {
        try { Thread.sleep(ms) } catch (_: InterruptedException) {}
    }
}
