package com.budspopup

import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Context
import java.io.ByteArrayOutputStream
import java.util.UUID

/**
 * Пряме читання заряду L / R / кейс з навушників realme / OPPO / OnePlus по Bluetooth RFCOMM
 * (той самий канал, яким користується realme Link / HeyMelody).
 *
 * Кадр: AA <len> 00 00 <команда LE16> <seq> <довжина даних LE16> <дані>
 * Команда 0x0106 = заряд, відповідь 0x8106: пари (id, рівень | 0x80 якщо заряджається); 1 = L, 2 = R, 3 = кейс.
 */
object OppoRfcomm {
    private val UUID_OPPO: UUID = UUID.fromString("0000079a-d102-11e1-9b23-00025b00a5a5")

    // ЗГАДАНА команда перемикання шумозаглушення. Не перевірено на T310, див. діагностику.
    private const val ANC_CMD = 0x0F01

    class Levels(val left: Int?, val right: Int?, val caseLvl: Int?)

    private fun frame(cmd: Int, seq: Int): ByteArray = byteArrayOf(
        0xAA.toByte(), 7, 0, 0,
        (cmd and 0xFF).toByte(), ((cmd shr 8) and 0xFF).toByte(),
        seq.toByte(), 0, 0
    )

    private fun hex(b: ByteArray, n: Int) = (0 until n).joinToString(" ") { "%02X".format(b[it]) }

    private fun open(ctx: Context, d: BluetoothDevice): BluetoothSocket? {
        try {
            val s = d.createRfcommSocketToServiceRecord(UUID_OPPO)
            s.connect()
            Diag.add(ctx, "RFCOMM: підключено за UUID")
            return s
        } catch (e: Exception) {
            Diag.add(ctx, "RFCOMM: UUID не вдалося: ${e.message}")
        }
        for (ch in intArrayOf(15, 12, 13)) {
            try {
                val m = BluetoothDevice::class.java.getMethod("createRfcommSocket", Int::class.javaPrimitiveType)
                val s = m.invoke(d, ch) as BluetoothSocket
                s.connect()
                Diag.add(ctx, "RFCOMM: підключено на каналі $ch")
                return s
            } catch (e: Throwable) {
                Diag.add(ctx, "RFCOMM: канал $ch не вдалося: ${e.message}")
            }
        }
        return null
    }

    /** Для пасивного слухання: відкриває канал (ті самі спроби, що й для заряду). */
    fun connectForListen(ctx: Context, d: BluetoothDevice): BluetoothSocket? = open(ctx, d)

    /** Перший кадр рукостискання, який шлемо один раз при відкритті. */
    fun handshakeBytes(): ByteArray = frame(0x0100, 1)

    fun hexOf(b: ByteArray, n: Int): String = hex(b, n)

    /** Блокуючий виклик (виконувати не в головному потоці). */
    fun fetch(ctx: Context, d: BluetoothDevice): Levels? {
        val s = open(ctx, d) ?: return null
        try {
            val out = s.outputStream
            val inp = s.inputStream
            out.write(frame(0x0100, 1)); out.flush()
            out.write(frame(0x0106, 2)); out.flush()
            val all = ByteArrayOutputStream()
            val tmp = ByteArray(512)
            val end = System.currentTimeMillis() + 3500
            while (System.currentTimeMillis() < end) {
                if (inp.available() > 0) {
                    val n = inp.read(tmp)
                    if (n <= 0) break
                    all.write(tmp, 0, n)
                    Diag.add(ctx, "RFCOMM rx ${hex(tmp, n)}")
                    val r = parse(all.toByteArray())
                    if (r != null) return r
                } else {
                    Thread.sleep(50)
                }
            }
            Diag.add(ctx, "RFCOMM: відповіді із зарядом не було")
        } catch (e: Exception) {
            Diag.add(ctx, "RFCOMM помилка: ${e.message}")
        } finally {
            try { s.close() } catch (_: Exception) {}
        }
        return null
    }

    /**
     * ЕКСПЕРИМЕНТАЛЬНО: перемикає шумозаглушення. mode: 0 вимкнено, 1 шумозаглушення, 2 прозорий режим.
     * Команду і формат для T310 не перевірено: кожна відповідь навушників записується в діагностику.
     */
    fun setMode(ctx: Context, d: BluetoothDevice, mode: Int): Boolean {
        val s = open(ctx, d) ?: return false
        try {
            val payload = byteArrayOf(mode.toByte())
            val out = s.outputStream
            out.write(framePl(ANC_CMD, 3, payload)); out.flush()
            Diag.add(ctx, "ANC надіслано mode=$mode cmd=%04X".format(ANC_CMD))
            val inp = s.inputStream
            val buf = ByteArrayOutputStream()
            val tmp = ByteArray(256)
            val end = System.currentTimeMillis() + 2000
            while (System.currentTimeMillis() < end) {
                if (inp.available() > 0) {
                    val n = inp.read(tmp)
                    if (n <= 0) break
                    buf.write(tmp, 0, n)
                    Diag.add(ctx, "ANC rx ${hex(tmp, n)}")
                } else {
                    Thread.sleep(50)
                }
            }
            if (buf.size() == 0) Diag.add(ctx, "ANC: відповіді не було")
            return true
        } catch (e: Exception) {
            Diag.add(ctx, "ANC помилка: ${e.message}")
            return false
        } finally {
            try { s.close() } catch (_: Exception) {}
        }
    }

    /**
     * ПОШУК КОМАНДИ (експеримент): по черзі надсилає команди з діапазону з режимом 1
     * і записує будь-яку відповідь навушників у діагностику. Під час пошуку навушники можуть перемикатися.
     */
    fun scanAnc(ctx: Context, d: BluetoothDevice) {
        val s = open(ctx, d) ?: return
        try {
            val out = s.outputStream
            val inp = s.inputStream
            fun drain(tag: String, cmd: Int) {
                val tmp = ByteArray(256)
                val buf = ByteArrayOutputStream()
                val end = System.currentTimeMillis() + 250
                while (System.currentTimeMillis() < end) {
                    if (inp.available() > 0) {
                        val n = inp.read(tmp)
                        if (n <= 0) break
                        buf.write(tmp, 0, n)
                    } else {
                        Thread.sleep(20)
                    }
                }
                if (buf.size() > 0) Diag.add(ctx, "SCAN $tag cmd=%04X rx ${hex(buf.toByteArray(), buf.size())}".format(cmd))
            }
            Diag.add(ctx, "SCAN старт")
            out.write(frame(0x0100, 1)); out.flush()
            drain("handshake", 0x0100)
            for (cmd in 0x0101..0x0130) {
                out.write(framePl(cmd, 2, byteArrayOf(1))); out.flush()
                drain("try", cmd)
            }
            Diag.add(ctx, "SCAN кінець")
        } catch (e: Exception) {
            Diag.add(ctx, "SCAN помилка: ${e.message}")
        } finally {
            try { s.close() } catch (_: Exception) {}
        }
    }

    /** Кадр з даними: AA, довжина, 00 00, команда LE16, seq, довжина даних LE16, дані. */
    private fun framePl(cmd: Int, seq: Int, data: ByteArray): ByteArray {
        val n = data.size
        val head = byteArrayOf(
            0xAA.toByte(), (7 + n).toByte(), 0, 0,
            (cmd and 0xFF).toByte(), ((cmd shr 8) and 0xFF).toByte(),
            seq.toByte(), (n and 0xFF).toByte(), ((n shr 8) and 0xFF).toByte()
        )
        return head + data
    }

    private fun parse(b: ByteArray): Levels? {
        var i = 0
        while (i + 9 <= b.size) {
            if ((b[i].toInt() and 0xFF) != 0xAA) { i++; continue }
            val len = b[i + 1].toInt() and 0xFF
            val total = 2 + len
            if (i + total > b.size) break
            val cmd = (b[i + 4].toInt() and 0xFF) or ((b[i + 5].toInt() and 0xFF) shl 8)
            val plen = (b[i + 7].toInt() and 0xFF) or ((b[i + 8].toInt() and 0xFF) shl 8)
            if (cmd == 0x8106 && i + 9 + plen <= b.size) {
                return levels(b.copyOfRange(i + 9, i + 9 + plen))
            }
            i += total
        }
        return null
    }

    private fun levels(p: ByteArray): Levels? {
        var l: Int? = null
        var r: Int? = null
        var c: Int? = null
        var k = if (p.size % 2 == 1) 1 else 0   // інколи першим байтом іде кількість записів
        while (k + 1 < p.size) {
            val id = p[k].toInt() and 0xFF
            val v = p[k + 1].toInt() and 0x7F
            if (v in 0..100) when (id) { 1 -> l = v; 2 -> r = v; 3 -> c = v }
            k += 2
        }
        return if (l != null || r != null || c != null) Levels(l, r, c) else null
    }
}
