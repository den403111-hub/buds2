package com.budspopup

import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator

class PopupService : Service() {

    private lateinit var ui: PopupUi
    private val handler = Handler(Looper.getMainLooper())
    private val battery: Battery get() = BatteryHub.battery
    private var current: BluetoothDevice? = null
    private var lastShow = 0L
    private var registered = false
    private val io = java.util.concurrent.Executors.newSingleThreadExecutor()
    private var rfcommBusy = false
    private val alerted = mutableSetOf<String>()
    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == "statusnotif" || key == "name") updateStatus()
    }
    private val pollRunnable = object : Runnable {
        override fun run() {
            if (current == null) return
            refreshRfcomm()
            handler.postDelayed(this, pollMs())
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        ui = PopupUi(this)
        ui.onAnc = { mode ->
            io.execute { current?.let { d -> OppoRfcomm.setMode(this, d, mode) } }
        }
        BatteryHub.onChange = { updateAll() }

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("buds", "Buds Popup", NotificationManager.IMPORTANCE_MIN))
        nm.createNotificationChannel(NotificationChannel("low", "Низький заряд", NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel("status", "Заряд навушників", NotificationManager.IMPORTANCE_LOW))
        val n = buildStatusNotification()
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
            } else {
                startForeground(1, n)
            }
        } catch (e: Exception) {
            stopSelf()
            return
        }

        val f = IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
            addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED)
            addAction(ACTION_BATTERY)
            addAction(ACTION_VENDOR)
            addCategory(CATEGORY_APPLE)   // +IPHONEACCEV: заряд, який шлють деякі навушники по HFP
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, f, Context.RECEIVER_EXPORTED)
        } else {
            registerReceiver(receiver, f)
        }
        registered = true
        getSharedPreferences("buds", Context.MODE_PRIVATE).registerOnSharedPreferenceChangeListener(prefListener)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "LISTEN") {
            current?.let { PassiveListener.start(this, it) } ?: Diag.add(this, "LISTEN: навушники ще не підключені")
        }
        if (intent?.action == "UNLISTEN") {
            PassiveListener.stop(this)
        }
        if (intent?.action == "SCAN") {
            io.execute { current?.let { d -> OppoRfcomm.scanAnc(this, d) } }
        }
        if (intent?.action == "TEST") {
            val t = Battery().apply { left = 80; right = 80; caseLevel = 20 }
            ui.show(Prefs.get(this, "name", "realme Buds T310"), t)
            ui.playConnectSound()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        if (registered) {
            unregisterReceiver(receiver)
            getSharedPreferences("buds", Context.MODE_PRIVATE).unregisterOnSharedPreferenceChangeListener(prefListener)
        }
        BatteryHub.onChange = null
        handler.removeCallbacks(pollRunnable)
        io.shutdown()
        ui.dismissNow()
        super.onDestroy()
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val dev: BluetoothDevice? = if (Build.VERSION.SDK_INT >= 33) {
                i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
            } else {
                @Suppress("DEPRECATION") i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
            }
            when (i.action) {
                BluetoothDevice.ACTION_ACL_CONNECTED -> if (matches(dev)) onConnected(dev!!)
                BluetoothDevice.ACTION_ACL_DISCONNECTED ->
                    if (dev != null && dev.address == current?.address) {
                        current = null
                        handler.removeCallbacks(pollRunnable)
                        alerted.clear()
                        ui.dismiss()
                        updateStatus()
                    }
                ACTION_BATTERY -> if (dev != null && dev.address == current?.address) {
                    val lvl = i.getIntExtra(EXTRA_BATTERY, -1)
                    Diag.add(this@PopupService, "BATTERY_LEVEL_CHANGED $lvl")
                    if (lvl in 0..100) {
                        battery.total = lvl
                        updateAll()
                    }
                }
                ACTION_VENDOR -> if (dev == null || dev.address == current?.address) onVendor(i)
            }
        }
    }

    private fun onVendor(i: Intent) {
        val cmd = i.getStringExtra(EXTRA_VCMD) ?: return
        @Suppress("DEPRECATION") val args = i.getSerializableExtra(EXTRA_VARGS) as? Array<*>
        val list = args?.map { it?.toString() } ?: emptyList()
        Diag.add(this, "VENDOR $cmd $list")
        if (cmd == "+IPHONEACCEV") {
            val n = list.getOrNull(0)?.toIntOrNull() ?: return
            for (k in 0 until n) {
                val key = list.getOrNull(1 + 2 * k)?.toIntOrNull()
                val v = list.getOrNull(2 + 2 * k)?.toIntOrNull()
                if (key == 1 && v != null && v in 0..9) {
                    battery.total = (v + 1) * 10
                    updateAll()
                }
            }
        }
    }

    private fun nameOf(d: BluetoothDevice?): String? =
        try { d?.name } catch (_: SecurityException) { null }

    private fun matches(d: BluetoothDevice?): Boolean {
        if (d == null) return false
        val f = Prefs.get(this, "filter", "T310").trim()
        if (f.isEmpty()) return true
        return nameOf(d)?.contains(f, ignoreCase = true) == true
    }

    private fun onConnected(d: BluetoothDevice) {
        val now = System.currentTimeMillis()
        if (d.address == current?.address && now - lastShow < 3000) return
        lastShow = now
        current = d
        BatteryHub.reset()
        Diag.add(this, "CONNECTED ${nameOf(d)}")
        dumpDevice(d)
        updateStatus()

        val locked = getSystemService(KeyguardManager::class.java)?.isKeyguardLocked == true
        if (!(Prefs.bool(this, "skiplock") && locked)) {
            ui.show(Prefs.get(this, "name", "realme Buds T310"), battery)
            ui.playConnectSound()
            if (Prefs.bool(this, "vib")) vibrate()
        }
        alerted.clear()
        handler.removeCallbacks(pollRunnable)
        if (Prefs.bool(this, "lowalert", true)) handler.postDelayed(pollRunnable, pollMs())

        // Заряд приходить із затримкою, тому перечитуємо кілька разів
        for (delay in longArrayOf(1500, 3500, 6000)) {
            handler.postDelayed({ refreshBattery() }, delay)
        }
    }

    private fun refreshBattery() {
        val d = current ?: return
        // 1) Загальний заряд через Bluetooth (прихований API; на деяких телефонах не працює)
        try {
            val v = BluetoothDevice::class.java.getMethod("getBatteryLevel").invoke(d) as Int
            if (v in 0..100) battery.total = v
        } catch (_: Throwable) {
        }
        // 2) Заряд L / R / кейс з метаданих Bluetooth (їх, якщо підтримується, пише система або realme Link)
        fun meta(key: Int): Int? = readMetadata(d, key)?.toIntOrNull()?.takeIf { it in 0..100 }
        meta(10)?.let { battery.left = it }
        meta(11)?.let { battery.right = it }
        meta(12)?.let { battery.caseLevel = it }
        // 3) Пряме читання L / R / кейс по RFCOMM (протокол realme Link / HeyMelody)
        refreshRfcomm()
        // 4) Заряд зі сповіщень realme Link (якщо дано доступ до сповіщень)
        BatteryHub.rescan?.invoke()
        updateAll()
        Diag.add(this, "REFRESH total=${battery.total} L=${battery.left} R=${battery.right} case=${battery.caseLevel}")
    }

    private fun pollMs(): Long = Prefs.int(this, "pollmin", 3).coerceIn(1, 30) * 60_000L

    /** Оновлює popup і перевіряє, чи не низький заряд. */
    private fun updateAll() {
        ui.updateBattery(battery)
        checkLow()
        updateStatus()
    }

    // ---------- постійне сповіщення в шторці ----------

    private fun p(v: Int?): String = v?.let { "$it%" } ?: "—"

    private fun buildStatusNotification(): Notification {
        if (!Prefs.bool(this, "statusnotif", true)) {
            return Notification.Builder(this, "buds")
                .setContentTitle("Buds Popup працює")
                .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
                .build()
        }
        val b = battery
        val title: String
        val line1: String
        val line2: String
        if (current == null) {
            title = "Buds Popup"
            line1 = "Очікую підключення навушників"
            line2 = line1
        } else {
            val l = b.left
            val r = b.right
            title = Prefs.get(this, "name", "realme Buds T310")
            if (l != null || r != null) {
                line1 = "L ${p(l)}  ·  R ${p(r)}  ·  Кейс ${p(b.caseLevel)}"
                line2 = "Лівий: ${p(l)}\nПравий: ${p(r)}\nКейс: ${p(b.caseLevel)}"
            } else {
                line1 = "🎧 ${p(b.total)}  ·  Кейс ${p(b.caseLevel)}"
                line2 = "Навушники: ${p(b.total)}\nКейс: ${p(b.caseLevel)}"
            }
        }
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, "status")
            .setContentTitle(title)
            .setContentText(line1)
            .setStyle(Notification.BigTextStyle().bigText(line2))
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setContentIntent(pi)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .build()
    }

    private fun updateStatus() {
        try {
            getSystemService(NotificationManager::class.java).notify(1, buildStatusNotification())
        } catch (_: Exception) {
        }
    }

    private fun checkLow() {
        if (!Prefs.bool(this, "lowalert", true)) return
        val thr = Prefs.int(this, "lowthr", 20)
        val items = listOf(
            "Лівий навушник" to battery.left,
            "Правий навушник" to battery.right,
            "Кейс" to battery.caseLevel,
            "Навушники" to (if (battery.left == null && battery.right == null) battery.total else null)
        )
        for ((label, v) in items) {
            // 0% = навушник у закритому кейсі / дані недоступні: не попереджаємо
            if (v == null || v <= 0) continue
            if (v <= thr) {
                if (alerted.add(label)) notifyLow(label, v)
            } else if (v > thr + 5) {
                alerted.remove(label)
            }
        }
    }

    private fun notifyLow(label: String, v: Int) {
        try {
            val n = Notification.Builder(this, "low")
                .setContentTitle("🔋 Низький заряд")
                .setContentText("$label: $v%")
                .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
                .setAutoCancel(true)
                .build()
            getSystemService(NotificationManager::class.java).notify(label.hashCode(), n)
        } catch (_: Exception) {
        }
        if (Prefs.bool(this, "lowpopup", true)) {
            ui.show(Prefs.get(this, "name", "realme Buds T310"), battery)
        }
    }

    private fun vibrate() {
        try {
            val v = getSystemService(Vibrator::class.java)
            v?.vibrate(VibrationEffect.createOneShot(45, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (_: Exception) {
        }
    }

    private fun refreshRfcomm() {
        val d = current ?: return
        if (rfcommBusy || PassiveListener.running) return
        rfcommBusy = true
        io.execute {
            val lv = try { OppoRfcomm.fetch(this, d) } catch (_: Throwable) { null }
            handler.post {
                rfcommBusy = false
                if (lv != null) {
                    lv.left?.let { battery.left = it }
                    lv.right?.let { battery.right = it }
                    lv.caseLvl?.let { battery.caseLevel = it }
                    Diag.add(this, "RFCOMM OK L=${lv.left} R=${lv.right} case=${lv.caseLvl}")
                    updateAll()
                }
            }
        }
    }

    /** Читає метадані пристрою (прихований API). Ключі 10, 11, 12 = заряд лівого, правого, кейса. */
    private fun readMetadata(d: BluetoothDevice, key: Int): String? = try {
        val m = BluetoothDevice::class.java.getMethod("getMetadata", Int::class.javaPrimitiveType)
        (m.invoke(d, key) as? ByteArray)?.let { String(it) }?.trim()?.takeIf { it.isNotEmpty() }
    } catch (_: Throwable) {
        null
    }

    /** Один раз при підключенні записує в журнал усе, що відомо про пристрій. */
    private fun dumpDevice(d: BluetoothDevice) {
        try {
            val uuids = try { d.uuids?.joinToString { it.uuid.toString() } } catch (_: Throwable) { null }
            Diag.add(this, "DEVICE name=${nameOf(d)} addr=${d.address} type=${d.type} uuids=$uuids")
            val meta = (0..15).joinToString(" ") { k -> "$k=${readMetadata(d, k)?.take(40)}" }
            Diag.add(this, "META $meta")
        } catch (_: Throwable) {
        }
    }

    companion object {
        const val ACTION_BATTERY = "android.bluetooth.device.action.BATTERY_LEVEL_CHANGED"
        const val EXTRA_BATTERY = "android.bluetooth.device.extra.BATTERY_LEVEL"
        const val ACTION_VENDOR = "android.bluetooth.headset.action.VENDOR_SPECIFIC_HEADSET_EVENT"
        const val EXTRA_VCMD = "android.bluetooth.headset.extra.VENDOR_SPECIFIC_HEADSET_EVENT_CMD"
        const val EXTRA_VARGS = "android.bluetooth.headset.extra.VENDOR_SPECIFIC_HEADSET_EVENT_ARGS"
        const val CATEGORY_APPLE = "android.bluetooth.headset.intent.category.companyid.76"
    }
}
