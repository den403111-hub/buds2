package com.budspopup

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import kotlin.math.cos
import kotlin.math.sin

/**
 * Процедурний малюнок інею: блакитний градієнт і папороподібні кристали.
 * Створюється один раз і кешується, тому при показі popup нічого не гальмує.
 */
object Frost {
    private var cached: Bitmap? = null

    fun get(ctx: Context, w: Int, h: Int): Bitmap {
        cached?.let { if (it.width == w && it.height == h) return it }
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val bg = Paint().apply {
            shader = LinearGradient(
                0f, 0f, 0f, h.toFloat(),
                intArrayOf(0xFFEAF5FF.toInt(), 0xFFBBD9F7.toInt(), 0xFF8EBEEC.toInt()),
                null, Shader.TileMode.CLAMP
            )
        }
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), bg)

        val d = ctx.resources.displayMetrics.density
        val rnd = java.util.Random(7)
        val bright = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            color = 0xCCFFFFFF.toInt()
            strokeWidth = 1.1f * d
        }
        val faint = Paint(bright).apply {
            color = 0x55FFFFFF
            strokeWidth = 0.7f * d
        }
        var budget = 9000

        fun branch(x: Float, y: Float, ang: Float, len: Float, depth: Int, p: Paint) {
            if (depth == 0 || len < 2f || budget <= 0) return
            budget--
            val ex = x + cos(ang) * len
            val ey = y + sin(ang) * len
            c.drawLine(x, y, ex, ey, p)
            val n = 2 + rnd.nextInt(2)
            for (k in 0 until n) {
                branch(ex, ey, ang + (rnd.nextFloat() - 0.5f) * 1.6f, len * (0.6f + rnd.nextFloat() * 0.2f), depth - 1, p)
            }
        }

        val starts = (w * h) / 15000
        for (i in 0 until starts) {
            val x = rnd.nextFloat() * w
            val y = rnd.nextFloat() * h
            val base = rnd.nextFloat() * 6.28f
            // кілька променів від однієї точки дають вигляд кристала
            for (k in 0 until 3) {
                branch(x, y, base + k * 2.09f, (12f + rnd.nextFloat() * 14f) * d, 5, bright)
            }
            branch(x, y, base + 0.5f, (8f + rnd.nextFloat() * 10f) * d, 4, faint)
        }
        cached = bmp
        return bmp
    }
}
