package com.budspopup

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {

    private val BG = 0xFF121218.toInt()
    private val CARD = 0xFF1E1E28.toInt()
    private val BTN2 = 0xFF2B2B3A.toInt()
    private val ACCENT = 0xFF7C5CFF.toInt()
    private val MUTED = 0xFF9A9AAE.toInt()

    private lateinit var etFilter: EditText
    private lateinit var etName: EditText
    private lateinit var etSecs: EditText
    private lateinit var chipBt: TextView
    private lateinit var chipOv: TextView
    private lateinit var chipNl: TextView
    private lateinit var curColor: View

    private val swatches = intArrayOf(
        0xFFFFFFFF.toInt(), 0xFF00E5FF.toInt(), 0xFF2979FF.toInt(), 0xFF7C5CFF.toInt(), 0xFFB14CFF.toInt(),
        0xFFFF2D95.toInt(), 0xFFFF3030.toInt(), 0xFFFF9100.toInt(), 0xFFFFD600.toInt(), 0xFF39FF14.toInt(),
        0xFF00BFA5.toInt(), 0xFFFF80AB.toInt()
    )

    private class Theme(val name: String, val values: Map<String, Any>)

    private val themes = listOf(
        Theme("Мінімал", mapOf("shape" to 0, "radius" to 28, "bfx" to 0)),
        Theme("Кібер-неон", mapOf("shape" to 3, "radius" to 22, "bfx" to 3, "bhex" to "#00E5FF", "bw" to 3)),
        Theme("Веселка", mapOf("shape" to 0, "radius" to 32, "bfx" to 4, "bw" to 3)),
        Theme("Скло", mapOf("shape" to 1, "bfx" to 1, "bhex" to "#FFFFFF", "bw" to 2)),
        Theme("Вогонь", mapOf("shape" to 4, "radius" to 30, "bfx" to 5, "bhex" to "#FF9100", "bw" to 4)),
        Theme("Сакура", mapOf("shape" to 0, "radius" to 40, "bfx" to 2, "bhex" to "#FF2D95", "bw" to 3))
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setBackgroundDrawable(ColorDrawable(BG))
        window.statusBarColor = BG
        window.navigationBarColor = BG

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(36), dp(16), dp(32))
        }
        setContentView(ScrollView(this).apply { addView(col) })

        header(col)
        statusChips(col)

        // ---------- Швидкий старт ----------
        val start = section(col, "🚀", "Швидкий старт")
        note(start, "Дозволи потрібні один раз. Потім натисни «Увімкнути».")
        button(start, "1. Дозволи (Bluetooth, сповіщення)") { requestPerms() }
        button(start, "2. Показ поверх вікон") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        button(start, "3. Робота у фоні (без обмежень батареї)") {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }
        button(start, "Тест popup", primary = true) { startSvc("TEST") }
        button(start, "▶ Увімкнути (працює у фоні)", primary = true) {
            Prefs.putBool(this, "enabled", true); startSvc()
        }
        button(start, "■ Вимкнути") {
            Prefs.putBool(this, "enabled", false)
            stopService(Intent(this, PopupService::class.java))
            toast("Вимкнено")
        }

        // ---------- Пристрій ----------
        val dev = section(col, "🎧", "Пристрій")
        etFilter = field(dev, "Назва Bluetooth-пристрою містить (пусто = будь-який)", Prefs.get(this, "filter", "T310"))
        etName = field(dev, "Назва в popup", Prefs.get(this, "name", "realme Buds T310"))
        etSecs = field(dev, "Скільки секунд показувати", Prefs.get(this, "secs", "7"))
        etSecs.inputType = InputType.TYPE_CLASS_NUMBER

        // ---------- Розмір і позиція ----------
        val size = section(col, "📐", "Розмір і позиція")
        seek(size, "Ширина вікна", "w", 60, 100, 100, "%")
        seek(size, "Висота вікна", "h", 240, 420, 270, " dp")
        seek(size, "Розмір картинок", "img", 60, 130, 100, " dp")
        seek(size, "Відступ від краю екрана", "mb", 0, 160, 16, " dp")
        spin(size, "Позиція", "pos", listOf("Знизу", "Зверху"))

        // ---------- Анімація ----------
        val an = section(col, "✨", "Анімація")
        spin(an, "Як з'являється popup", "anim", listOf(
            "Виїзд з краю (пружина)", "Виїзд з краю (плавно)", "Збільшення + поява",
            "Відскок", "Збоку", "Просто поява"
        ))

        // ---------- Форма і рамка ----------
        val look = section(col, "🎨", "Форма і рамка")
        themeRow(look)
        spin(look, "Форма вікна", "shape", listOf("Закруглений", "Пігулка", "Гострі кути", "Зрізані кути", "Асиметричний"))
        seek(look, "Закруглення / зріз кутів", "radius", 0, 60, 28, " dp")
        spin(look, "Рамка / ефект", "bfx", listOf(
            "Без рамки", "Проста рамка", "Неон (світіння)", "Неон пульсація",
            "Веселка (кольори по колу)", "Біжучий вогник"
        ))
        colorRow(look)
        seek(look, "Товщина рамки", "bw", 1, 8, 3, " dp")

        // ---------- Фон і картинки ----------
        val pics = section(col, "🖼", "Фон і картинки")
        button(pics, "Фон: GIF / фото / відео") { pick(REQ_BG, arrayOf("image/*", "video/*")) }
        button(pics, "Фото навушників (краще PNG без фону)") { pick(REQ_BUDS, arrayOf("image/*")) }
        button(pics, "Фото кейса (краще PNG без фону)") { pick(REQ_CASE, arrayOf("image/*")) }
        button(pics, "Скинути вигляд") {
            listOf("bg", "buds", "case", "bg_poster.jpg").forEach { File(filesDir, it).delete() }
            toast("Скинуто")
        }

        // ---------- Заряд ----------
        val bat = section(col, "🔋", "Заряд")
        toggle(bat, "Попередження про низький заряд", "lowalert", true)
        seek(bat, "Поріг попередження", "lowthr", 5, 50, 20, "%")
        toggle(bat, "Показувати popup при попередженні", "lowpopup", true)
        seek(bat, "Перевіряти заряд кожні", "pollmin", 1, 15, 3, " хв")
        note(bat, "Поки навушники підключені, додаток періодично питає їх про заряд, щоб вчасно попередити.")

        // ---------- Додатково ----------
        val more = section(col, "⚙️", "Додатково")
        toggle(more, "Вібрація при підключенні", "vib", false)
        toggle(more, "Не показувати на екрані блокування", "skiplock", false)

        // ---------- Діагностика ----------
        val dg = section(col, "🛠", "Діагностика")
        note(dg, "Заряд L/R/кейс читається напряму з навушників. Якщо щось не працює, натисни «Діагностика», скопіюй текст і надішли розробнику.")
        button(dg, "Діагностика (що приходить від навушників)") { showDiag() }
        button(dg, "Доступ до сповіщень (необов'язково)") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
    }

    override fun onResume() {
        super.onResume()
        setChip(chipBt, "Bluetooth", hasBt())
        setChip(chipOv, "Поверх вікон", Settings.canDrawOverlays(this))
        val nl = packageName in (Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: "")
        setChip(chipNl, "Сповіщення", nl)
    }

    override fun onPause() {
        saveFields()
        super.onPause()
    }

    // ---------- UI-хелпери ----------

    private fun rounded(color: Int, rDp: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(rDp).toFloat()
    }

    private fun lp(topDp: Int = 0) = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(topDp) }

    private fun header(col: LinearLayout) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(
            ImageView(this).apply { setImageDrawable(packageManager.getApplicationIcon(packageName)) },
            LinearLayout.LayoutParams(dp(60), dp(60))
        )
        val t = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), 0, 0, 0) }
        t.addView(TextView(this).apply {
            text = "Buds Popup"; textSize = 26f; setTextColor(Color.WHITE); setTypeface(null, Typeface.BOLD)
        })
        t.addView(TextView(this).apply {
            text = "красивий popup для твоїх навушників"; textSize = 13f; setTextColor(MUTED)
        })
        row.addView(t)
        col.addView(row)
    }

    private fun statusChips(col: LinearLayout) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        chipBt = chip(); chipOv = chip(); chipNl = chip()
        chipBt.setOnClickListener { requestPerms() }
        chipOv.setOnClickListener {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        chipNl.setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        for (c in listOf(chipBt, chipOv, chipNl)) {
            row.addView(c, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply { marginEnd = dp(6) })
        }
        col.addView(row, lp(16))
    }

    private fun chip() = TextView(this).apply {
        textSize = 12f
        gravity = Gravity.CENTER
        setTextColor(Color.WHITE)
        setPadding(dp(6), dp(8), dp(6), dp(8))
        background = rounded(BTN2, 14)
    }

    private fun setChip(c: TextView, label: String, ok: Boolean) {
        c.text = (if (ok) "✅ " else "❌ ") + label
        c.background = rounded(if (ok) 0xFF1F3D2B.toInt() else 0xFF45252B.toInt(), 14)
    }

    private fun section(parent: LinearLayout, emoji: String, title: String): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(CARD, 20)
            setPadding(dp(16), dp(14), dp(16), dp(16))
        }
        card.addView(TextView(this).apply {
            text = "$emoji  $title"; textSize = 17f; setTextColor(Color.WHITE); setTypeface(null, Typeface.BOLD)
        })
        parent.addView(card, lp(14))
        return card
    }

    private fun note(parent: LinearLayout, t: String) {
        parent.addView(TextView(this).apply { text = t; textSize = 12.5f; setTextColor(MUTED) }, lp(6))
    }

    private fun label(parent: LinearLayout, t: String) {
        parent.addView(TextView(this).apply { text = t; textSize = 13.5f; setTextColor(0xFFDDDDEE.toInt()) }, lp(12))
    }

    private fun button(parent: LinearLayout, t: String, primary: Boolean = false, onClick: () -> Unit) {
        val b = Button(this).apply {
            text = t
            isAllCaps = false
            textSize = 14.5f
            setTextColor(Color.WHITE)
            stateListAnimator = null
            background = rounded(if (primary) ACCENT else BTN2, 14)
            minHeight = dp(46)
            minimumHeight = dp(46)
            setOnClickListener { onClick() }
        }
        parent.addView(b, lp(8))
    }

    private fun field(parent: LinearLayout, hint: String, value: String): EditText {
        label(parent, hint)
        val e = EditText(this).apply {
            setText(value)
            setSingleLine()
            setTextColor(Color.WHITE)
            textSize = 15f
            background = rounded(BTN2, 12)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        parent.addView(e, lp(4))
        return e
    }

    private fun seek(parent: LinearLayout, title: String, key: String, min: Int, max: Int, def: Int, unit: String) {
        val cur = Prefs.int(this, key, def).coerceIn(min, max)
        val tv = TextView(this).apply { text = "$title: $cur$unit"; textSize = 13.5f; setTextColor(0xFFDDDDEE.toInt()) }
        val sb = SeekBar(this).apply {
            this.max = max - min
            progress = cur - min
            progressTintList = ColorStateList.valueOf(ACCENT)
            thumbTintList = ColorStateList.valueOf(ACCENT)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    val v = p + min
                    tv.text = "$title: $v$unit"
                    Prefs.putInt(this@MainActivity, key, v)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        parent.addView(tv, lp(12))
        parent.addView(sb, lp(0))
    }

    private fun spin(parent: LinearLayout, title: String, key: String, items: List<String>, def: Int = 0) {
        label(parent, title)
        val sp = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
            setSelection(Prefs.int(this@MainActivity, key, def).coerceIn(0, items.size - 1))
            background = rounded(BTN2, 12)
            setPadding(dp(8), dp(8), dp(8), dp(8))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, position: Int, id: Long) {
                    Prefs.putInt(this@MainActivity, key, position)
                }
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
        }
        parent.addView(sp, lp(4))
    }

    private fun toggle(parent: LinearLayout, title: String, key: String, def: Boolean) {
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        val sw = Switch(this).apply {
            text = title
            textSize = 14.5f
            setTextColor(Color.WHITE)
            isChecked = Prefs.bool(this@MainActivity, key, def)
            thumbTintList = ColorStateList(states, intArrayOf(ACCENT, 0xFFAAAAAA.toInt()))
            trackTintList = ColorStateList(states, intArrayOf(0x887C5CFF.toInt(), 0x55888888))
            setOnCheckedChangeListener { _, v -> Prefs.putBool(this@MainActivity, key, v) }
        }
        parent.addView(sw, lp(12))
    }

    // ---------- Готові стилі і вибір кольору ----------

    private fun themeRow(parent: LinearLayout) {
        label(parent, "Готові стилі (один тап)")
        val hs = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (t in themes) {
            row.addView(
                TextView(this).apply {
                    text = t.name
                    textSize = 13.5f
                    setTextColor(Color.WHITE)
                    background = rounded(BTN2, 18)
                    setPadding(dp(14), dp(9), dp(14), dp(9))
                    setOnClickListener { applyTheme(t) }
                },
                LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { marginEnd = dp(8) }
            )
        }
        hs.addView(row)
        parent.addView(hs, lp(6))
    }

    private fun applyTheme(t: Theme) {
        saveFields()
        for ((k, v) in t.values) {
            when (v) {
                is Int -> Prefs.putInt(this, k, v)
                is String -> Prefs.put(this, k, v)
            }
        }
        toast("Стиль «${t.name}» застосовано")
        recreate()
    }

    private fun circle(color: Int, sizeDp: Int) = View(this).apply {
        background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
            setStroke(dp(2), 0x66FFFFFF)
        }
    }

    private fun colorRow(parent: LinearLayout) {
        label(parent, "Колір рамки")
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        curColor = circle(Colors.border(this), 30)
        row.addView(curColor, LinearLayout.LayoutParams(dp(34), dp(34)).apply { marginEnd = dp(12) })
        val hs = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val sw = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (c in swatches) {
            sw.addView(
                circle(c, 30).apply { setOnClickListener { setBorderColor(c) } },
                LinearLayout.LayoutParams(dp(34), dp(34)).apply { marginEnd = dp(10) }
            )
        }
        hs.addView(sw)
        row.addView(hs, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        parent.addView(row, lp(6))
        button(parent, "Палітра: будь-який колір…") { colorDialog() }
    }

    private fun setBorderColor(c: Int) {
        Prefs.put(this, "bhex", Colors.toHex(c))
        curColor.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(c)
            setStroke(dp(2), 0x66FFFFFF)
        }
    }

    private class Track(val frame: View, val bar: View, val sb: SeekBar)

    private fun track(max: Int, init: Int, onChange: () -> Unit): Track {
        val frame = FrameLayout(this)
        val bar = View(this)
        frame.addView(
            bar,
            FrameLayout.LayoutParams(MATCH_PARENT, dp(14)).apply {
                gravity = Gravity.CENTER_VERTICAL
                setMargins(dp(10), 0, dp(10), 0)
            }
        )
        val sb = SeekBar(this).apply {
            this.max = max
            progress = init
            progressDrawable = ColorDrawable(Color.TRANSPARENT)
            thumbTintList = ColorStateList.valueOf(Color.WHITE)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { onChange() }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        frame.addView(sb, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        return Track(frame, bar, sb)
    }

    private fun colorDialog() {
        val hsv = FloatArray(3)
        Color.colorToHSV(Colors.border(this), hsv)
        var chosen = Colors.border(this)
        var refresh: () -> Unit = {}

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(8))
        }
        val preview = View(this)
        box.addView(preview, LinearLayout.LayoutParams(MATCH_PARENT, dp(56)))
        val hexTv = TextView(this).apply { gravity = Gravity.CENTER; setTextColor(Color.WHITE); textSize = 14f }
        box.addView(hexTv, lp(6))

        val th = track(360, hsv[0].toInt()) { refresh() }
        val ts = track(100, (hsv[1] * 100).toInt()) { refresh() }
        val tv = track(100, (hsv[2] * 100).toInt()) { refresh() }
        th.bar.background = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(
                0xFFFF0000.toInt(), 0xFFFFFF00.toInt(), 0xFF00FF00.toInt(),
                0xFF00FFFF.toInt(), 0xFF0000FF.toInt(), 0xFFFF00FF.toInt(), 0xFFFF0000.toInt()
            )
        ).apply { cornerRadius = dp(7).toFloat() }
        box.addView(TextView(this).apply { text = "Відтінок"; setTextColor(MUTED); textSize = 12f }, lp(10))
        box.addView(th.frame, lp(0))
        box.addView(TextView(this).apply { text = "Насиченість"; setTextColor(MUTED); textSize = 12f }, lp(6))
        box.addView(ts.frame, lp(0))
        box.addView(TextView(this).apply { text = "Яскравість"; setTextColor(MUTED); textSize = 12f }, lp(6))
        box.addView(tv.frame, lp(0))

        refresh = {
            hsv[0] = th.sb.progress.toFloat()
            hsv[1] = ts.sb.progress / 100f
            hsv[2] = tv.sb.progress / 100f
            val c = Color.HSVToColor(hsv)
            chosen = c
            preview.background = rounded(c, 14)
            hexTv.text = Colors.toHex(c)
            val full = Color.HSVToColor(floatArrayOf(hsv[0], 1f, 1f))
            ts.bar.background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.WHITE, full))
                .apply { cornerRadius = dp(7).toFloat() }
            tv.bar.background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.BLACK, full))
                .apply { cornerRadius = dp(7).toFloat() }
        }
        refresh()

        AlertDialog.Builder(this)
            .setTitle("Колір рамки")
            .setView(box)
            .setPositiveButton("Готово") { _, _ -> setBorderColor(chosen) }
            .setNegativeButton("Скасувати", null)
            .show()
    }

    // ---------- Діагностика ----------

    private fun showDiag() {
        val tv = TextView(this).apply {
            text = Diag.read(this@MainActivity)
            textSize = 12f
            setTextIsSelectable(true)
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        AlertDialog.Builder(this)
            .setTitle("Діагностика")
            .setView(ScrollView(this).apply { addView(tv) })
            .setPositiveButton("Копіювати") { _, _ ->
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("diag", Diag.read(this)))
                toast("Скопійовано")
            }
            .setNeutralButton("Очистити") { _, _ -> Diag.clear(this) }
            .setNegativeButton("Закрити", null)
            .show()
    }

    // ---------- логіка ----------

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun saveFields() {
        if (!::etFilter.isInitialized) return
        Prefs.put(this, "filter", etFilter.text.toString())
        Prefs.put(this, "name", etName.text.toString())
        Prefs.put(this, "secs", etSecs.text.toString())
    }

    private fun hasBt() = Build.VERSION.SDK_INT < 31 ||
        checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    private fun requestPerms() {
        val l = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 31) l += Manifest.permission.BLUETOOTH_CONNECT
        if (Build.VERSION.SDK_INT >= 33) l += Manifest.permission.POST_NOTIFICATIONS
        if (l.isNotEmpty()) requestPermissions(l.toTypedArray(), 10)
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        onResume()
    }

    private fun startSvc(action: String? = null) {
        saveFields()
        if (!hasBt()) { toast("Спочатку дай дозволи (крок 1)"); return }
        if (!Settings.canDrawOverlays(this)) { toast("Дозволь показ поверх вікон (крок 2)"); return }
        try {
            startForegroundService(Intent(this, PopupService::class.java).apply { this.action = action })
        } catch (e: Exception) {
            toast("Помилка: ${e.message}")
        }
    }

    private fun pick(req: Int, mimes: Array<String>) {
        val i = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, mimes)
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        @Suppress("DEPRECATION")
        startActivityForResult(i, req)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (res != RESULT_OK) return
        val uri = data?.data ?: return
        val name = when (req) { REQ_BG -> "bg"; REQ_BUDS -> "buds"; REQ_CASE -> "case"; else -> return }
        val mime = contentResolver.getType(uri) ?: ""
        Thread {
            try {
                contentResolver.openInputStream(uri)?.use { inp ->
                    File(filesDir, name).outputStream().use { out -> inp.copyTo(out) }
                }
                if (req == REQ_BG) {
                    Prefs.putBool(this, "bg_video", mime.startsWith("video"))
                    File(filesDir, "bg_poster.jpg").delete()   // новий фон = новий кадр-заглушка
                }
                runOnUiThread { toast("Збережено") }
            } catch (e: Exception) {
                runOnUiThread { toast("Помилка: ${e.message}") }
            }
        }.start()
    }

    companion object {
        const val REQ_BG = 1
        const val REQ_BUDS = 2
        const val REQ_CASE = 3
    }
}
