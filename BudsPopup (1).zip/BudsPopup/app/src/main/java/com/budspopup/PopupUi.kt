package com.budspopup

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.AnimatedImageDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.WindowManager
import android.view.animation.AccelerateInterpolator
import android.view.animation.BounceInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.VideoView

class PopupUi(private val ctx: Context) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private var root: FrameLayout? = null
    private var card: View? = null
    private var budsBox: LinearLayout? = null
    private var caseBox: LinearLayout? = null
    private var video: VideoView? = null

    private val pos get() = Prefs.int(ctx, "pos", 0)      // 0 знизу, 1 зверху
    private val anim get() = Prefs.int(ctx, "anim", 0)

    fun show(name: String, b: Battery) {
        if (!Settings.canDrawOverlays(ctx)) return
        dismissNow()

        val dm = ctx.resources.displayMetrics
        val sz = Prefs.int(ctx, "img", 100)
        val cardW = ((dm.widthPixels - ctx.dp(24)) * Prefs.int(ctx, "w", 100) / 100f).toInt()
        val cardH = ctx.dp(maxOf(Prefs.int(ctx, "h", 270), sz + 150))

        val c = buildCard(name, b, sz)
        val r = FrameLayout(ctx)
        val top = pos == 1
        r.addView(
            c,
            FrameLayout.LayoutParams(cardW, cardH).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                setMargins(0, if (top) ctx.dp(12) else ctx.dp(12), 0, if (top) ctx.dp(12) else ctx.dp(28))
            }
        )
        val lp = WindowManager.LayoutParams(
            MATCH_PARENT, WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = if (top) Gravity.TOP else Gravity.BOTTOM
        wm.addView(r, lp)
        root = r
        card = c
        animateIn(c)

        val secs = Prefs.get(ctx, "secs", "7").toIntOrNull() ?: 7
        handler.postDelayed({ dismiss() }, secs * 1000L)
    }

    fun updateBattery(b: Battery) {
        budsBox?.let { fillBuds(it, b) }
        caseBox?.let { fillCase(it, b) }
    }

    // ---------- анімації ----------
    // 0 пружина з краю, 1 плавний виїзд, 2 збільшення, 3 відскок, 4 збоку, 5 просто поява

    private fun offY(c: View): Float = (c.height + ctx.dp(80)) * (if (pos == 1) -1f else 1f)
    private fun offX(): Float = ctx.resources.displayMetrics.widthPixels.toFloat()

    private fun animateIn(c: View) {
        val t = anim
        c.alpha = 0f
        c.post {
            c.pivotX = c.width / 2f
            c.pivotY = c.height / 2f
            val a = c.animate()
            when (t) {
                0 -> { c.translationY = offY(c); c.alpha = 1f
                    a.translationY(0f).setDuration(450).setInterpolator(OvershootInterpolator(0.9f)) }
                1 -> { c.translationY = offY(c); c.alpha = 1f
                    a.translationY(0f).setDuration(380).setInterpolator(DecelerateInterpolator(2f)) }
                2 -> { c.scaleX = 0.6f; c.scaleY = 0.6f
                    a.alpha(1f).scaleX(1f).scaleY(1f).setDuration(380).setInterpolator(OvershootInterpolator(1.4f)) }
                3 -> { c.translationY = offY(c); c.alpha = 1f
                    a.translationY(0f).setDuration(750).setInterpolator(BounceInterpolator()) }
                4 -> { c.translationX = offX(); c.alpha = 1f
                    a.translationX(0f).setDuration(420).setInterpolator(DecelerateInterpolator(1.8f)) }
                else -> a.alpha(1f).setDuration(350)
            }
            a.start()
        }
    }

    fun dismiss() {
        val c = card ?: return
        val a = c.animate().setDuration(260).setInterpolator(AccelerateInterpolator())
        when (anim) {
            2 -> a.alpha(0f).scaleX(0.7f).scaleY(0.7f)
            5 -> a.alpha(0f)
            4 -> a.translationX(offX())
            else -> a.translationY(offY(c))
        }
        a.withEndAction { if (card === c) dismissNow() }.start()
    }

    fun dismissNow() {
        handler.removeCallbacksAndMessages(null)
        video?.stopPlayback()
        video = null
        root?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        root = null; card = null; budsBox = null; caseBox = null
    }

    // ---------- побудова картки ----------

    private fun buildCard(name: String, b: Battery, sz: Int): FrameLayout {
        val c = FrameLayout(ctx)
        c.background = GradientDrawable().apply {
            cornerRadius = ctx.dp(28).toFloat()
            setColor(0xFF1B1B1F.toInt())
        }
        c.clipToOutline = true
        c.elevation = ctx.dp(10).toFloat()
        c.setOnClickListener { dismiss() }

        addBackground(c)

        c.addView(
            View(ctx).apply {
                background = GradientDrawable(
                    GradientDrawable.Orientation.TOP_BOTTOM,
                    intArrayOf(0x00000000, 0xB0000000.toInt())
                )
            },
            FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT)
        )

        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ctx.dp(18), ctx.dp(14), ctx.dp(18), ctx.dp(16))
        }

        // дві колонки: навушники + заряд під ними, кейс + заряд під ним
        val bb = batteryBox(); val cb = batteryBox()
        budsBox = bb; caseBox = cb
        fillBuds(bb, b); fillCase(cb, b)

        val top = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        top.addView(column("buds", R.drawable.ic_buds, bb, sz), LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        top.addView(column("case", R.drawable.ic_case, cb, sz), LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        col.addView(top, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))

        col.addView(
            TextView(ctx).apply {
                text = name
                setTextColor(Color.WHITE)
                textSize = 20f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER_HORIZONTAL
                setShadowLayer(6f, 0f, 1f, Color.BLACK)
            },
            LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply {
                topMargin = ctx.dp(4); bottomMargin = ctx.dp(8)
            }
        )

        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(
            pill("Setting", Color.WHITE, Color.BLACK) { dismiss(); openBtSettings() },
            LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply { marginEnd = ctx.dp(6) }
        )
        row.addView(
            pill("Open", 0xFF444444.toInt(), Color.WHITE) { dismiss(); openCompanionApp() },
            LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply { marginStart = ctx.dp(6) }
        )
        col.addView(row, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        c.addView(col, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        return c
    }

    private fun batteryBox() = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
    }

    private fun column(file: String, placeholder: Int, box: LinearLayout, sz: Int) = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        addView(img(file, placeholder), LinearLayout.LayoutParams(ctx.dp(sz), ctx.dp(sz)))
        addView(box, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { topMargin = ctx.dp(4) })
    }

    private fun addBackground(c: FrameLayout) {
        val f = Prefs.file(ctx, "bg") ?: return
        try {
            if (Prefs.bool(ctx, "bg_video")) {
                val vv = VideoView(ctx)
                vv.setVideoURI(Uri.fromFile(f))
                vv.setOnPreparedListener { mp -> mp.isLooping = true; mp.setVolume(0f, 0f) }
                c.addView(vv, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT, Gravity.CENTER))
                vv.start()
                video = vv
            } else {
                val iv = ImageView(ctx)
                iv.scaleType = ImageView.ScaleType.CENTER_CROP
                val d = ImageDecoder.decodeDrawable(ImageDecoder.createSource(f))
                iv.setImageDrawable(d)
                if (d is AnimatedImageDrawable) {
                    d.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE
                    d.start()
                }
                c.addView(iv, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
            }
        } catch (_: Exception) {
        }
    }

    private fun img(fileName: String, placeholder: Int): ImageView = ImageView(ctx).apply {
        scaleType = ImageView.ScaleType.FIT_CENTER
        val f = Prefs.file(ctx, fileName)
        if (f != null) {
            setImageURI(Uri.fromFile(f))
        } else {
            setImageResource(placeholder)
            setColorFilter(Color.WHITE)
        }
    }

    private fun pct(v: Int?): String = v?.let { "$it%" } ?: "—"

    private fun fillBuds(box: LinearLayout, b: Battery) {
        box.removeAllViews()
        val s = when {
            b.left != null || b.right != null -> "L ${pct(b.left)}  ·  R ${pct(b.right)}"
            b.total != null -> "🎧 ${b.total}%"
            else -> "…"
        }
        box.addView(batText(s))
    }

    private fun fillCase(box: LinearLayout, b: Battery) {
        box.removeAllViews()
        box.addView(batText("Кейс ${pct(b.caseLevel)}"))
    }

    private fun batText(s: String) = TextView(ctx).apply {
        text = s
        setTextColor(Color.WHITE)
        textSize = 15f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setShadowLayer(6f, 0f, 1f, Color.BLACK)
    }

    private fun pill(label: String, bg: Int, fg: Int, onClick: () -> Unit) = TextView(ctx).apply {
        text = label
        gravity = Gravity.CENTER
        setTextColor(fg)
        textSize = 15f
        typeface = Typeface.DEFAULT_BOLD
        background = GradientDrawable().apply {
            cornerRadius = ctx.dp(24).toFloat()
            setColor(bg)
        }
        setPadding(0, ctx.dp(12), 0, ctx.dp(12))
        setOnClickListener { onClick() }
    }

    private fun openBtSettings() {
        try {
            ctx.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
        }
    }

    private fun openCompanionApp() {
        for (p in listOf("com.realme.link", "com.heytap.headset", "com.oplus.melody")) {
            val i = ctx.packageManager.getLaunchIntentForPackage(p)
            if (i != null) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try { ctx.startActivity(i) } catch (_: Exception) {}
                return
            }
        }
        openBtSettings()
    }
}
