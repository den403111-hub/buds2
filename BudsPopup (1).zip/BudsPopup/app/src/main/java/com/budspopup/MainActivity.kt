package com.budspopup

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {

    private lateinit var etFilter: EditText
    private lateinit var etName: EditText
    private lateinit var etSecs: EditText
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(40), dp(20), dp(40))
        }
        setContentView(ScrollView(this).apply { addView(col) })

        col.addView(TextView(this).apply {
            text = "Buds Popup"; textSize = 28f; setTypeface(null, Typeface.BOLD)
        })
        status = TextView(this).apply { setPadding(0, dp(8), 0, dp(12)) }
        col.addView(status)

        col.addView(label("Налаштування по черзі"))
        col.addView(btn("1. Дозволи (Bluetooth, сповіщення)") { requestPerms() })
        col.addView(btn("2. Дозволити показ поверх вікон") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        col.addView(btn("3. Без обмежень батареї (щоб працювало у фоні)") {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        })

        col.addView(label("Пристрій"))
        col.addView(small("Назва Bluetooth-пристрою містить (пусто = будь-який)"))
        etFilter = field(Prefs.get(this, "filter", "T310")); col.addView(etFilter)
        col.addView(small("Назва в popup"))
        etName = field(Prefs.get(this, "name", "realme Buds T310")); col.addView(etName)
        col.addView(small("Скільки секунд показувати"))
        etSecs = field(Prefs.get(this, "secs", "7")).apply { inputType = InputType.TYPE_CLASS_NUMBER }
        col.addView(etSecs)

        col.addView(label("Розмір і позиція"))
        col.addView(seek("Ширина вікна", "w", 60, 100, 100, "%"))
        col.addView(seek("Висота вікна", "h", 240, 420, 270, " dp"))
        col.addView(seek("Розмір картинок", "img", 60, 130, 100, " dp"))
        col.addView(small("Позиція"))
        col.addView(spinner("pos", listOf("Знизу", "Зверху")))

        col.addView(label("Анімація"))
        col.addView(spinner("anim", listOf(
            "Виїзд з краю (пружина)",
            "Виїзд з краю (плавно)",
            "Збільшення + поява",
            "Відскок",
            "Збоку",
            "Просто поява"
        )))

        col.addView(label("Вигляд"))
        col.addView(btn("Фон: GIF / фото / відео") { pick(REQ_BG, arrayOf("image/*", "video/*")) })
        col.addView(btn("Фото навушників (краще PNG без фону)") { pick(REQ_BUDS, arrayOf("image/*")) })
        col.addView(btn("Фото кейса (краще PNG без фону)") { pick(REQ_CASE, arrayOf("image/*")) })
        col.addView(btn("Скинути вигляд") {
            listOf("bg", "buds", "case").forEach { File(filesDir, it).delete() }
            toast("Скинуто")
        })

        col.addView(label("Заряд з realme Link (експеримент)"))
        col.addView(small("Додаток читає сповіщення realme Link / HeyMelody і шукає там заряд L, R і кейса. Якщо там його немає, буде показано лише загальний заряд з Bluetooth."))
        col.addView(btn("Дати доступ до сповіщень") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        col.addView(btn("Діагностика (що приходить від навушників)") { showDiag() })

        col.addView(label("Запуск"))
        col.addView(btn("Тест popup") { startSvc("TEST") })
        col.addView(btn("▶ Увімкнути (працює у фоні)") {
            Prefs.putBool(this, "enabled", true); startSvc()
        })
        col.addView(btn("■ Вимкнути") {
            Prefs.putBool(this, "enabled", false)
            stopService(Intent(this, PopupService::class.java))
            toast("Вимкнено")
        })
    }

    override fun onResume() {
        super.onResume()
        val bt = if (hasBt()) "✅" else "❌"
        val ov = if (Settings.canDrawOverlays(this)) "✅" else "❌"
        val nl = if (packageName in (Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: "")) "✅" else "❌"
        status.text = "Bluetooth: $bt   Поверх вікон: $ov   Сповіщення: $nl"
    }

    override fun onPause() {
        saveFields()
        super.onPause()
    }

    // ---------- helpers ----------

    private fun label(t: String) = TextView(this).apply {
        text = t; textSize = 18f; setTypeface(null, Typeface.BOLD); setPadding(0, dp(20), 0, dp(4))
    }

    private fun small(t: String) = TextView(this).apply {
        text = t; textSize = 13f; alpha = 0.75f; setPadding(0, dp(6), 0, dp(2))
    }

    private fun btn(t: String, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setOnClickListener { f() }
    }

    private fun field(v: String) = EditText(this).apply { setText(v); setSingleLine() }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun seek(title: String, key: String, min: Int, max: Int, def: Int, unit: String): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(6), 0, dp(2)) }
        val cur = Prefs.int(this, key, def).coerceIn(min, max)
        val tv = TextView(this).apply { text = "$title: $cur$unit" }
        val sb = SeekBar(this).apply {
            this.max = max - min
            progress = cur - min
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    val v = p + min
                    tv.text = "$title: $v$unit"
                    Prefs.putInt(this@MainActivity, key, v)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        box.addView(tv)
        box.addView(sb)
        return box
    }

    private fun spinner(key: String, items: List<String>): Spinner = Spinner(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
        setSelection(Prefs.int(this@MainActivity, key, 0).coerceIn(0, items.size - 1))
        onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, position: Int, id: Long) {
                Prefs.putInt(this@MainActivity, key, position)
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }

    private fun showDiag() {
        val tv = TextView(this).apply {
            text = Diag.read(this@MainActivity)
            textSize = 12f
            setTextIsSelectable(true)
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        AlertDialog.Builder(this)
            .setTitle("Діагностика")
            .setView(ScrollView(this).apply { addView(tv) })
            .setPositiveButton("Копіювати") { _, _ ->
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("diag", Diag.read(this)))
                toast("Скопійовано")
            }
            .setNeutralButton("Очистити") { _, _ -> Diag.clear(this) }
            .setNegativeButton("Закрити", null)
            .show()
    }

    private fun saveFields() {
        if (!::etFilter.isInitialized) return
        Prefs.put(this, "filter", etFilter.text.toString())
        Prefs.put(this, "name", etName.text.toString())
        Prefs.put(this, "secs", etSecs.text.toString())
    }

    private fun hasBt() = Build.VERSION.SDK_INT < 31 ||
        checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    private fun requestPerms() {
        val l = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 31) l += Manifest.permission.BLUETOOTH_CONNECT
        if (Build.VERSION.SDK_INT >= 33) l += Manifest.permission.POST_NOTIFICATIONS
        if (l.isNotEmpty()) requestPermissions(l.toTypedArray(), 10)
    }

    private fun startSvc(action: String? = null) {
        saveFields()
        if (!hasBt()) { toast("Спочатку дай дозволи (крок 1)"); return }
        if (!Settings.canDrawOverlays(this)) { toast("Дозволь показ поверх вікон (крок 2)"); return }
        try {
            startForegroundService(Intent(this, PopupService::class.java).apply { this.action = action })
        } catch (e: Exception) {
            toast("Помилка: ${e.message}")
        }
    }

    private fun pick(req: Int, mimes: Array<String>) {
        val i = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, mimes)
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        @Suppress("DEPRECATION")
        startActivityForResult(i, req)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (res != RESULT_OK) return
        val uri = data?.data ?: return
        val name = when (req) { REQ_BG -> "bg"; REQ_BUDS -> "buds"; REQ_CASE -> "case"; else -> return }
        val mime = contentResolver.getType(uri) ?: ""
        Thread {
            try {
                contentResolver.openInputStream(uri)?.use { inp ->
                    File(filesDir, name).outputStream().use { out -> inp.copyTo(out) }
                }
                if (req == REQ_BG) Prefs.putBool(this, "bg_video", mime.startsWith("video"))
                runOnUiThread { toast("Збережено") }
            } catch (e: Exception) {
                runOnUiThread { toast("Помилка: ${e.message}") }
            }
        }.start()
    }

    companion object {
        const val REQ_BG = 1
        const val REQ_BUDS = 2
        const val REQ_CASE = 3
    }
}
