package com.budspopup

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper

class PopupService : Service() {

    private lateinit var ui: PopupUi
    private val handler = Handler(Looper.getMainLooper())
    private val battery: Battery get() = BatteryHub.battery
    private var current: BluetoothDevice? = null
    private var lastShow = 0L
    private var registered = false
    private val io = java.util.concurrent.Executors.newSingleThreadExecutor()
    private var rfcommBusy = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        ui = PopupUi(this)
        BatteryHub.onChange = { ui.updateBattery(battery) }

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("buds", "Buds Popup", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "buds")
            .setContentTitle("Buds Popup працює")
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .build()
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
            } else {
                startForeground(1, n)
            }
        } catch (e: Exception) {
            stopSelf()
            return
        }

        val f = IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
            addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED)
            addAction(ACTION_BATTERY)
            addAction(ACTION_VENDOR)
            addCategory(CATEGORY_APPLE)   // +IPHONEACCEV: заряд, який шлють деякі навушники по HFP
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, f, Context.RECEIVER_EXPORTED)
        } else {
            registerReceiver(receiver, f)
        }
        registered = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "TEST") {
            val t = Battery().apply { left = 80; right = 80; caseLevel = 20 }
            ui.show(Prefs.get(this, "name", "realme Buds T310"), t)
        }
        return START_STICKY
    }

    override fun onDestroy() {
        if (registered) unregisterReceiver(receiver)
        BatteryHub.onChange = null
        io.shutdown()
        ui.dismissNow()
        super.onDestroy()
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val dev: BluetoothDevice? = if (Build.VERSION.SDK_INT >= 33) {
                i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
            } else {
                @Suppress("DEPRECATION") i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
            }
            when (i.action) {
                BluetoothDevice.ACTION_ACL_CONNECTED -> if (matches(dev)) onConnected(dev!!)
                BluetoothDevice.ACTION_ACL_DISCONNECTED ->
                    if (dev != null && dev.address == current?.address) ui.dismiss()
                ACTION_BATTERY -> if (dev != null && dev.address == current?.address) {
                    val lvl = i.getIntExtra(EXTRA_BATTERY, -1)
                    Diag.add(this@PopupService, "BATTERY_LEVEL_CHANGED $lvl")
                    if (lvl in 0..100) {
                        battery.total = lvl
                        ui.updateBattery(battery)
                    }
                }
                ACTION_VENDOR -> if (dev == null || dev.address == current?.address) onVendor(i)
            }
        }
    }

    private fun onVendor(i: Intent) {
        val cmd = i.getStringExtra(EXTRA_VCMD) ?: return
        @Suppress("DEPRECATION") val args = i.getSerializableExtra(EXTRA_VARGS) as? Array<*>
        val list = args?.map { it?.toString() } ?: emptyList()
        Diag.add(this, "VENDOR $cmd $list")
        if (cmd == "+IPHONEACCEV") {
            val n = list.getOrNull(0)?.toIntOrNull() ?: return
            for (k in 0 until n) {
                val key = list.getOrNull(1 + 2 * k)?.toIntOrNull()
                val v = list.getOrNull(2 + 2 * k)?.toIntOrNull()
                if (key == 1 && v != null && v in 0..9) {
                    battery.total = (v + 1) * 10
                    ui.updateBattery(battery)
                }
            }
        }
    }

    private fun nameOf(d: BluetoothDevice?): String? =
        try { d?.name } catch (_: SecurityException) { null }

    private fun matches(d: BluetoothDevice?): Boolean {
        if (d == null) return false
        val f = Prefs.get(this, "filter", "T310").trim()
        if (f.isEmpty()) return true
        return nameOf(d)?.contains(f, ignoreCase = true) == true
    }

    private fun onConnected(d: BluetoothDevice) {
        val now = System.currentTimeMillis()
        if (d.address == current?.address && now - lastShow < 3000) return
        lastShow = now
        current = d
        BatteryHub.reset()
        Diag.add(this, "CONNECTED ${nameOf(d)}")
        dumpDevice(d)

        ui.show(Prefs.get(this, "name", "realme Buds T310"), battery)

        // Заряд приходить із затримкою, тому перечитуємо кілька разів
        for (delay in longArrayOf(1500, 3500, 6000)) {
            handler.postDelayed({ refreshBattery() }, delay)
        }
    }

    private fun refreshBattery() {
        val d = current ?: return
        // 1) Загальний заряд через Bluetooth (прихований API; на деяких телефонах не працює)
        try {
            val v = BluetoothDevice::class.java.getMethod("getBatteryLevel").invoke(d) as Int
            if (v in 0..100) battery.total = v
        } catch (_: Throwable) {
        }
        // 2) Заряд L / R / кейс з метаданих Bluetooth (їх, якщо підтримується, пише система або realme Link)
        fun meta(key: Int): Int? = readMetadata(d, key)?.toIntOrNull()?.takeIf { it in 0..100 }
        meta(10)?.let { battery.left = it }
        meta(11)?.let { battery.right = it }
        meta(12)?.let { battery.caseLevel = it }
        // 3) Пряме читання L / R / кейс по RFCOMM (протокол realme Link / HeyMelody)
        refreshRfcomm()
        // 4) Заряд зі сповіщень realme Link (якщо дано доступ до сповіщень)
        BatteryHub.rescan?.invoke()
        ui.updateBattery(battery)
        Diag.add(this, "REFRESH total=${battery.total} L=${battery.left} R=${battery.right} case=${battery.caseLevel}")
    }

    private fun refreshRfcomm() {
        val d = current ?: return
        if (rfcommBusy) return
        rfcommBusy = true
        io.execute {
            val lv = try { OppoRfcomm.fetch(this, d) } catch (_: Throwable) { null }
            handler.post {
                rfcommBusy = false
                if (lv != null) {
                    lv.left?.let { battery.left = it }
                    lv.right?.let { battery.right = it }
                    lv.caseLvl?.let { battery.caseLevel = it }
                    Diag.add(this, "RFCOMM OK L=${lv.left} R=${lv.right} case=${lv.caseLvl}")
                    ui.updateBattery(battery)
                }
            }
        }
    }

    /** Читає метадані пристрою (прихований API). Ключі 10, 11, 12 = заряд лівого, правого, кейса. */
    private fun readMetadata(d: BluetoothDevice, key: Int): String? = try {
        val m = BluetoothDevice::class.java.getMethod("getMetadata", Int::class.javaPrimitiveType)
        (m.invoke(d, key) as? ByteArray)?.let { String(it) }?.trim()?.takeIf { it.isNotEmpty() }
    } catch (_: Throwable) {
        null
    }

    /** Один раз при підключенні записує в журнал усе, що відомо про пристрій. */
    private fun dumpDevice(d: BluetoothDevice) {
        try {
            val uuids = try { d.uuids?.joinToString { it.uuid.toString() } } catch (_: Throwable) { null }
            Diag.add(this, "DEVICE name=${nameOf(d)} addr=${d.address} type=${d.type} uuids=$uuids")
            val meta = (0..15).joinToString(" ") { k -> "$k=${readMetadata(d, k)?.take(40)}" }
            Diag.add(this, "META $meta")
        } catch (_: Throwable) {
        }
    }

    companion object {
        const val ACTION_BATTERY = "android.bluetooth.device.action.BATTERY_LEVEL_CHANGED"
        const val EXTRA_BATTERY = "android.bluetooth.device.extra.BATTERY_LEVEL"
        const val ACTION_VENDOR = "android.bluetooth.headset.action.VENDOR_SPECIFIC_HEADSET_EVENT"
        const val EXTRA_VCMD = "android.bluetooth.headset.extra.VENDOR_SPECIFIC_HEADSET_EVENT_CMD"
        const val EXTRA_VARGS = "android.bluetooth.headset.extra.VENDOR_SPECIFIC_HEADSET_EVENT_ARGS"
        const val CATEGORY_APPLE = "android.bluetooth.headset.intent.category.companyid.76"
    }
}
