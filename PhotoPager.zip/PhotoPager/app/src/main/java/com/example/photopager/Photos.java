package com.example.photopager;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import java.io.*;
import java.util.*;

final class Photos {
    static File dir(Context c) { File d = new File(c.getFilesDir(), "photos"); d.mkdirs(); return d; }
    static File lockFile(Context c) { return new File(c.getFilesDir(), "lock.jpg"); }

    static List<File> list(Context c) {
        File[] f = dir(c).listFiles();
        List<File> l = new ArrayList<>();
        if (f != null) { Arrays.sort(f); l.addAll(Arrays.asList(f)); }
        return l;
    }

    static void save(Context c, Uri uri, File out) throws IOException {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        try (InputStream in = c.getContentResolver().openInputStream(uri)) { BitmapFactory.decodeStream(in, null, o); }
        int s = 1;
        while (Math.max(o.outWidth, o.outHeight) / s > 3000) s *= 2;
        o = new BitmapFactory.Options();
        o.inSampleSize = s;
        Bitmap b;
        try (InputStream in = c.getContentResolver().openInputStream(uri)) { b = BitmapFactory.decodeStream(in, null, o); }
        if (b == null) throw new IOException("decode failed");
        int rot = 0;
        try (InputStream in = c.getContentResolver().openInputStream(uri)) {
            int ori = new ExifInterface(in).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1);
            if (ori == 6) rot = 90; else if (ori == 3) rot = 180; else if (ori == 8) rot = 270;
        } catch (Exception ignored) { }
        if (rot != 0) {
            Matrix m = new Matrix();
            m.postRotate(rot);
            Bitmap r = Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), m, true);
            b.recycle();
            b = r;
        }
        try (FileOutputStream fo = new FileOutputStream(out)) { b.compress(Bitmap.CompressFormat.JPEG, 90, fo); }
        b.recycle();
    }
}
